# Auth Loader

This is implemented with Spring Boot with containerless deployment. 
Note the following files are included in the deployment artifact along with the code - these supply command line configuration
for the application, i.e.

    ARGS - contains the jar application arguments, those passed as args to your main method i.e. void main(String[] args)

    JVMARGS - parameters to be passed directly to the jvm via the -D flag, e.g. -DmyEnv=xyz

Within the container, the application will be deployed in the opt/app-root/app.jar location and executed as:

/usr/bin/java -DmyOption=abc -jar /opt/app-root/app.jar args0 args1 ...

### Endpoints

Spring Boot actuator provides information OOB for application health, status and general app build info - by default /info and /health are enabled. These type
of end points can be used by PaaS for healthcheck/readiness/liveness probes.

The following endpoints are available:

- /info
- /health

The health endpoint check has been modified to illustrate how to add additional checks and info can be included via implementing/extending the appropriate Spring Boot HealthIndicator
classes. Health status may be toggled by the following endpoints

- /forceHealthFail
- /resetHealth

When the aggregated health status is UP, /health returns a http 200; when it is DOWN, it returns 503.

### Environment specific configuration
The current PaaS environment is inferred by the ``envlevel`` environment indicator, as stored in the credentials API (see [PaaS Secrets/Credentials API](https://enterprise-confluence.aexp.com/confluence/pages/viewpage.action?pageId=132825329) and [creds.json](creds.json) for an example payload).
It is used here to set the active spring profile via
the following in the JVM arguments (see [JVMARGS](.openshift/JVMARGS) file):

    -Dspring.profiles.active=${envlevel}

This allows environment-specific configuration (see the properties files and Spring docs for more).




