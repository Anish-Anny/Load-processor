package com.aexp.gmnt.imc.compute.global;

import com.aexp.gms.risk.authload.exception.AuthLoadSystemException;

/**
 * @author akkore
 * @param <T>
 */
public interface IGmntIMCompute<T> {

  /**
   * @param object
   * @return
   * @throws IMCProcessException
   */
  public T call(T object) throws IMCProcessException, AuthLoadSystemException;
}
