package com.aexp.gmnt.imc.compute.global;

public interface IGmntIMCProcessor {

  public String process(String jsonMessage);
}
