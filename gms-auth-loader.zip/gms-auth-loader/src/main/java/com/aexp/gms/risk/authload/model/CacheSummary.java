package com.aexp.gms.risk.authload.model;

public class CacheSummary {

  private String cacheName;
  private int cacheCount;

  public String getCacheName() {
    return cacheName;
  }

  public void setCacheName(String cacheName) {
    this.cacheName = cacheName;
  }

  public int getCacheCount() {
    return cacheCount;
  }

  public void setCacheCount(int cacheCount) {
    this.cacheCount = cacheCount;
  }
}
