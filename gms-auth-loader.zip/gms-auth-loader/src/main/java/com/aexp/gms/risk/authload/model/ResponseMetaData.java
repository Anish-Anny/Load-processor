package com.aexp.gms.risk.authload.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@EqualsAndHashCode
public class ResponseMetaData {

  /* Handle following HTTP response codes
   * 200 OK
   * 400 Bad Request
   * 404 Not Found
   * 403 Forbidden
   * 500 Internal Server Error
   *
   */
  private String ResponseTime;

  private String Code = "";

  private String ShortMessage;

  @Override
  public String toString() {
    StringBuilder StringLog =
        new StringBuilder(1000)
            .append("ResponseMetaData [ResponseTime=")
            .append(ResponseTime)
            .append("Code=")
            .append(Code)
            .append("ShortMessage=")
            .append(ShortMessage)
            .append("]");
    return StringLog.toString();
  }
}
