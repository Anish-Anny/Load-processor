package com.aexp.gms.risk.authload.services;

import com.aexp.gms.risk.authload.exception.AuthLoadSystemException;
import com.aexp.gms.risk.authload.model.Authorization;
import com.aexp.gms.risk.authload.model.CacheSummaryResponse;
import com.aexp.gms.risk.authload.model.CasAuthTransIdCardResponse;

public interface AuthLoadService {
  public boolean activateIgnite() throws AuthLoadSystemException;

  public CacheSummaryResponse getCacheCount(String cacheName) throws AuthLoadSystemException;

  public boolean authLoadRequest(Authorization authorization);

  public boolean resetIgniteConnection() throws AuthLoadSystemException;

  public CasAuthTransIdCardResponse getAuthDetailsByTID(String transactionId)
      throws AuthLoadSystemException;

  public void validateCacheVersion();

  public int resetSemaphore(String semaPhoreName) throws AuthLoadSystemException;

  public void checkIgniteHealth();
}
