package com.aexp.gms.risk.authload.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoggingUtility {

  private static Logger logger = LoggerFactory.getLogger(LoggingUtility.class);

  private LoggingUtility() {}

  public static void trace(String msg) {
    logger.trace(msg);
  }

  public static void debug(String msg) {

    logger.debug(msg);
  }

  public static void error(String msg) {
    logger.error(msg);
  }

  public static void info(String msg) {
    logger.info(msg);
  }
}
