package com.aexp.gms.risk.authload.util;

import java.net.InetAddress;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuthLoadUtil {

  /**
   * Returns the Julian day number that begins at noon of this day, Positive year signifies A.D.,
   * negative year B.C. Remember that the year after 1 B.C. was 1 A.D.
   *
   * <p>ref : Numerical Recipes in C, 2nd ed., Cambridge University Press 1992
   */
  // Gregorian Calendar adopted Oct. 15, 1582 (2299161)
  public static final int JGREG = 15 + 31 * (10 + 12 * 1582);

  public static final double HALFSECOND = 0.5;
  private static final Logger logger = LoggerFactory.getLogger(AuthLoadUtil.class);

  public static final String TRANSACTION_DATE_TIME_FORMAT = "yyyy-MM-dd hh:mm:ss:SSS";

  public static final String OLD_TRANSACTION_DATE_TIME_FORMAT = "yyyy-MM-dd-hh:mm:ss.SSS";

  /*
   * This Utility method logs the Response time taken from respective
   * resource.
   */
  public static String getAPIResponseTime(long startTime) {

    StringBuilder stringLog =
        new StringBuilder(1000)
            .append(Instant.now().toEpochMilli() - startTime)
            .append(" - Milliseconds");
    return stringLog.toString();
  }

  /**
   * Identifies the current pod name
   *
   * @return
   */
  public static String getHostName() {
    String host = "";
    try {
      host = InetAddress.getLocalHost().getHostName();
    } catch (Exception e) {

      logger.error("Unable to retrieve host name {}", e);
    }
    return host;
  }

  public static String leftPad(String originalString, int length, char padCharacter) {
    StringBuilder sb = new StringBuilder();
    while (sb.length() + originalString.length() < length) {
      sb.append(padCharacter);
    }
    sb.append(originalString);

    return sb.toString();
  }

  public static String getCASPKey(String ecbCreationDate, String julian, String casLogIdentifier) {
    return ecbCreationDate.substring(0, 4)
        + leftPad(julian, 3, '0')
        + leftPad(casLogIdentifier, 10, '0');
  }

  public static String getCASPKey(Date date, String casLogIdentifier) {
    return toJulian(date) + leftPad(casLogIdentifier, 10, '0');
  }

  public static long toJulian(Date date) {

    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);

    String julian =
        String.valueOf(calendar.get(Calendar.YEAR))
            + leftPad(String.valueOf(calendar.get(Calendar.DAY_OF_YEAR)), 3, '0');

    return Long.parseLong(julian);
  }

  public static String getCASPKeyIDN(Date date, String casLogIdentifier) {
    return toJulian(date) + leftPad(casLogIdentifier, 10, '0');
  }

  public static Date getDateFromString(String transDateTime, String format) {

    Date transDate = null;
    DateFormat readFormat = new SimpleDateFormat(format);
    try {
      transDate = readFormat.parse(transDateTime);
    } catch (ParseException e) {
      logger.error("Unable to convert to Date :  {}  in Format :{} ", transDateTime, format);
    }
    return transDate;
  }
}
