package com.aexp.gms.risk.authload.util;
/**
 * @author vsunn1
 *     <p>To change the template for this generated type comment go to
 *     Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ITier {

  public static final int INPUTCOMPONENT = 0;
  public static final int OUTPUTCOMPONENT = 1;
  public static final int REQUESTHANDLER = 2;
  public static final int EJB = 3;
  public static final int DATAACCESSOR = 4;
  public static final int UTIL = 5;
  public static final int BUSINESSDELIGATOR = 6;
  public static final int SERVICE = 7;
}
