package com.aexp.gms.risk.authload.model;

import com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode2CacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode6CacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthTransIdCardCacheBean2;
import com.aexp.gms.risk.authload.util.AuthLoadUtil;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CacheBean {
  private final SimpleDateFormat casAuthorizationDateFormat = new SimpleDateFormat("MMddyy HHmmss");

  public CasAuthTransIdCardCacheBean2 getTidBean(Authorization authorization)
      throws ParseException {
    Date date = null;

    StringBuilder authorizationDate = new StringBuilder(15);
    CasAuthTransIdCardCacheBean2 cacheBean = new CasAuthTransIdCardCacheBean2();

    cacheBean.setCardNumber(authorization.getCardNumber());
    cacheBean.setTransactionId(authorization.getTransactionId());
    cacheBean.setAuthAmountUSD(new BigDecimal(authorization.getAuthAmountUSD()));
    cacheBean.setRocAuthMatchedFlag("N");
    cacheBean.setApproveDenyCode(authorization.getTransactionApproveDenyCode());
    cacheBean.setVoiceAuthIndicator(authorization.getVoiceAuthIndicator());
    cacheBean.setPosDataCode(authorization.getPosDataCode());
    cacheBean.setEciIndicator(authorization.getEciIndicator());
    cacheBean.setMccMerchant(authorization.getMcc());
    cacheBean.setCreditDeniedcode(authorization.getCreditWhyDeniedCode());
    cacheBean.setFraudDeniedCode(authorization.getFraudWhyDeniedCode());
    cacheBean.setAuthAmountCurrencyCode(authorization.getAuthAmountCurrencyCode());
    cacheBean.setAuthAmountLocal(new BigDecimal(authorization.getAuthAmountLocal()));

    authorizationDate.append(authorization.getAuthTransactionDate());
    authorizationDate.append(" ");
    authorizationDate.append(authorization.getAuthTransactionTime());
    casAuthorizationDateFormat.setLenient(false);
    date = casAuthorizationDateFormat.parse(authorizationDate.toString());
    cacheBean.setAuthTransactionDateTime(date);

    cacheBean.setSeNumber(authorization.getSeNumber());
    if (authorization.getEciIndicator() != null) {
      cacheBean.setAuthUniqueIdentifier(
          AuthLoadUtil.getCASPKey(
              authorization.getEciIndicator(),
              authorization.getEcbCreationTime(),
              authorization.getCasLogIdentifier()));
    } else {
      cacheBean.setAuthUniqueIdentifier(
          AuthLoadUtil.getCASPKeyIDN(date, authorization.getCasLogIdentifier()));
    }
    return cacheBean;
  }

  public CasAuthCardAccessCode6CacheBean getCardDac6Bean(Authorization authorization)
      throws ParseException {
    Date date = null;
    StringBuilder authorizationDate = new StringBuilder(15);

    CasAuthCardAccessCode6CacheBean cacheBean = new CasAuthCardAccessCode6CacheBean();

    cacheBean.setCardNumber(authorization.getCardNumber());
    cacheBean.setAuth6Dac(authorization.getAuth6dac());
    cacheBean.setApproveDenyCode(authorization.getTransactionApproveDenyCode());
    cacheBean.setAuthAmountUSD(new BigDecimal(authorization.getAuthAmountUSD()));
    cacheBean.setAuthAmountCurrencyCode(authorization.getAuthAmountCurrencyCode());
    cacheBean.setAuthAmountLocal(new BigDecimal(authorization.getAuthAmountLocal()));

    authorizationDate.append(authorization.getAuthTransactionDate());
    authorizationDate.append(" ");
    authorizationDate.append(authorization.getAuthTransactionTime());
    casAuthorizationDateFormat.setLenient(false);
    date = casAuthorizationDateFormat.parse(authorizationDate.toString());
    cacheBean.setAuthTransactionDateTime(date);

    cacheBean.setSeNumber(authorization.getSeNumber());
    if (authorization.getEciIndicator() != null) {
      cacheBean.setAuthUniqueIdentifier(
          AuthLoadUtil.getCASPKey(
              authorization.getEciIndicator(),
              authorization.getEcbCreationTime(),
              authorization.getCasLogIdentifier()));
    } else {
      cacheBean.setAuthUniqueIdentifier(
          AuthLoadUtil.getCASPKeyIDN(date, authorization.getCasLogIdentifier()));
    }
    return cacheBean;
  }

  public CasAuthCardAccessCode2CacheBean getCardDac2Bean(Authorization authorization)
      throws ParseException {
    Date date = null;
    StringBuilder authorizationDate = new StringBuilder(15);
    // StringBuffer authorizationDate = new StringBuffer(15);
    CasAuthCardAccessCode2CacheBean cacheBean = new CasAuthCardAccessCode2CacheBean();

    cacheBean.setCardNumber(authorization.getCardNumber());
    cacheBean.setAuth2Dac(authorization.getAuth2dac());
    cacheBean.setApproveDenyCode(authorization.getTransactionApproveDenyCode());
    cacheBean.setAuthAmountCurrencyCode(authorization.getAuthAmountCurrencyCode());
    cacheBean.setAuthAmountUSD(new BigDecimal(authorization.getAuthAmountUSD()));
    cacheBean.setAuthAmountLocal(new BigDecimal(authorization.getAuthAmountLocal()));

    authorizationDate.append(authorization.getAuthTransactionDate());
    authorizationDate.append(" ");
    authorizationDate.append(authorization.getAuthTransactionTime());
    casAuthorizationDateFormat.setLenient(false);
    date = casAuthorizationDateFormat.parse(authorizationDate.toString());
    cacheBean.setAuthTransactionDateTime(date);

    cacheBean.setSeNumber(authorization.getSeNumber());
    if (authorization.getEciIndicator() != null) {
      cacheBean.setAuthUniqueIdentifier(
          AuthLoadUtil.getCASPKey(
              authorization.getEciIndicator(),
              authorization.getEcbCreationTime(),
              authorization.getCasLogIdentifier()));
    } else {
      cacheBean.setAuthUniqueIdentifier(
          AuthLoadUtil.getCASPKeyIDN(date, authorization.getCasLogIdentifier()));
    }

    return cacheBean;
  }
}
