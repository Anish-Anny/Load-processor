package com.aexp.gms.risk.data;

import com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode2CacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode6CacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthTransIdCardCacheBean2;
import com.aexp.gms.risk.authload.exception.AuthLoadSystemException;
import com.aexp.gms.risk.authload.model.Authorization;
import com.datastax.driver.core.*;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import javax.annotation.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Created by rmanick on 6/4/2018. */
public class CassandraAuthDAOImpl {

  public static final String insertAuthQry =
      "insert into auth (trans_id,aprv_deny_cd, auth2dac_appr_cd, auth6dac_appr_cd, auth_am_in_local_curr, auth_am_in_usd, auth_curr, auth_dt, cas_pkey, cm15, frd_loss_prbl_score, frgn_sepnd_in, lwrcw_7dlog_tx, mag_swipe_in, mcc, se10, se_ctry_cd, se_indus_ctgy_cd, se_type_cd,auth_ts,sourceid) "
          + " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) USING TTL ? ";
  public static final String insertAuthCache_ByTransId_Qry =
      "insert into auth_by_trans_id (trans_id,cm_15,aprv_deny_cd,cas_pkey,auth_mtch_in,auth_se_no,auth_usd_am,auth_loc_am,card_2dac_cache_key, card_6dac_cache_key,auth_ts,auth_loc_am_curr_cd,voice_auth_in,pos_da_cd,eci_cd,mer_prvd_mcc_cd,cr_deny_rsn_cd,frd_deny_rsn_cd,trans_ts) "
          + " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) USING TTL ?";
  public static final String insertAuthCache_ByDac6_Qry =
      "insert into auth_by_6dac_and_se (cm15,six_dgt_aprv_cde,aprv_deny_cd,cas_pkey,auth_mtch_in,auth_se_no,auth_usd_am,auth_loc_am,auth_pref_am,card_2dac_cache_key, trans_id,auth_ts) "
          + " values (?,?,?,?,?,?,?,?,?,?,?,?) USING TTL ?";
  public static final String insertAuthCache_ByDac2_Qry =
      "insert into auth_by_2dac_and_se  (cm15,two_dgt_aprv_cde,aprv_deny_cd,cas_pkey,auth_mtch_in,auth_se_no,auth_usd_am,auth_loc_am,auth_pref_am,card_6dac_cache_key, trans_id,auth_ts) "
          + " values (?,?,?,?,?,?,?,?,?,?,?,?) USING TTL ?";
  public static final String insertAuthCache_ByCardAndSe_Qry =
      "insert into auth_by_card_and_se (auth_se_no,cm_15,aprv_deny_cd,auth_mtch_in,auth_ts,trans_id,auth_loc_am,auth_usd_am,card_2dac_cache_key,card_6dac_cache_key,cas_pkey,auth_loc_am_curr_cd,voice_auth_in,pos_da_cd,eci_cd,mer_prvd_mcc_cd,cr_deny_rsn_cd,frd_deny_rsn_cd,uuid_id) "
          + "values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,uuid()) USING TTL ?";
  private static PreparedStatement insertAuthPS = null;
  private static PreparedStatement insertAuthCacheByTransIDPS = null;
  private static PreparedStatement insertAuthCacheBy2DACPS = null;
  private static PreparedStatement insertAuthCacheBy6DACPS = null;
  private static PreparedStatement insertAuthCacheByCardAndSePS = null;
  private static final Logger logger = LoggerFactory.getLogger(CassandraAuthDAOImpl.class);

  private Statement insertAuth = null;
  private Statement insertAuthStatementCacheByTransID = null;
  private Statement insertAuthStatementCacheBy2DAC = null;
  private Statement insertAuthStatementCacheBy6DAC = null;
  private Statement insertAuthStatementCacheByCardAndSe = null;
  Session session = null;

  public void insertAuthorization(
      Authorization authorization,
      CasAuthTransIdCardCacheBean2 transCardBean,
      CasAuthCardAccessCode6CacheBean cardDac6Bean,
      CasAuthCardAccessCode2CacheBean cardDac2Bean)
      throws AuthLoadSystemException {
    try {

      session = CassandraConnectionFactory.getInstance().getCassandraSession();

      DateFormat targetTimeFormat = new SimpleDateFormat("HH:MM:SS");
      LocalTime time = null;

      try {
        if (authorization.getAuthTransactionTime() != null) {
          time =
              LocalTime.parse(
                  authorization.getAuthTransactionTime(), DateTimeFormatter.ofPattern("HHmmss"));
        }
      } catch (Exception e) {
        time = LocalTime.parse("00:00");
      }

      LocalDate localDate = null;

      try {
        if (authorization.getAuthTransactionDate() != null) {

          localDate =
              localDate.parse(
                  authorization.getAuthTransactionDate(), DateTimeFormatter.ofPattern("yyyyMMdd"));
        }
      } catch (Exception e) {
        localDate = LocalDate.parse("1900-01-01");
      }
      if (insertAuthPS == null) insertAuthPS = session.prepare(insertAuthQry);
      BatchStatement authBatch = new BatchStatement(BatchStatement.Type.UNLOGGED);

      Float fraudProbabilityScore;
      if (authorization.getFraudLossProbability() != null) {
        fraudProbabilityScore = authorization.getFraudLossProbability().floatValue();
      } else {
        fraudProbabilityScore = new Float("0.0");
      }

      // DERIVE TTL based  from days to seconds
      int timeToLive =
          (int) authorization.getExpiryPolicy().getExpiryForCreation().getDurationAmount()
              * 60
              * 60
              * 24;
      insertAuth =
          insertAuthPS.bind(
              authorization.getTransactionId(),
              authorization.getTransactionApproveDenyCode(),
              authorization.getAuth2dac(),
              authorization.getAuth6dac(),
              transCardBean.getAuthAmountLocal(),
              transCardBean.getAuthAmountUSD(),
              authorization.getAuthAmountCurrencyCode(),
              localDate,
              transCardBean.getAuthUniqueIdentifier(),
              transCardBean.getCardNumber(),
              fraudProbabilityScore,
              authorization.getForeignSpendIndicator(),
              authorization.getCasLogIdentifier(),
              authorization.getCasMessageSwipeIndicator(),
              authorization.getMcc(),
              authorization.getSeNumber(),
              authorization.getSeCountryCode(),
              authorization.getSeIndustryCategoryCode(),
              authorization.getSeType(),
              time,
              authorization.getSource(),
              timeToLive);

      authBatch.add(insertAuth);

      if (insertAuthCacheByTransIDPS == null)
        insertAuthCacheByTransIDPS = session.prepare(insertAuthCache_ByTransId_Qry);

      if (insertAuthCacheByCardAndSePS == null)
        insertAuthCacheByCardAndSePS = session.prepare(insertAuthCache_ByCardAndSe_Qry);

      if (insertAuthCacheBy6DACPS == null)
        insertAuthCacheBy6DACPS = session.prepare(insertAuthCache_ByDac6_Qry);

      if (insertAuthCacheBy2DACPS == null)
        insertAuthCacheBy2DACPS = session.prepare(insertAuthCache_ByDac2_Qry);

      insertAuthStatementCacheByTransID =
          insertAuthCacheByTransIDPS.bind(
              authorization.getTransactionId(),
              authorization.isTokenAvailable()
                  ? authorization.getDpan()
                  : authorization.getCardNumber(),
              transCardBean.getApproveDenyCode(),
              transCardBean.getAuthUniqueIdentifier(),
              "N",
              authorization.getSeNumber(),
              transCardBean.getAuthAmountUSD(),
              transCardBean.getAuthAmountLocal(),
              cardDac2Bean.getCacheStringKey(),
              cardDac6Bean.getCacheStringKey(),
              cardDac6Bean.getAuthTransactionDateTime().getTime(),
              authorization.getAuthAmountCurrencyCode(),
              authorization.getVoiceAuthIndicator(),
              authorization.getPosDataCode(),
              authorization.getEciIndicator(),
              authorization.getMcc(),
              authorization.getCreditWhyDeniedCode(),
              authorization.getFraudWhyDeniedCode(),
              transCardBean.getTransactionTimeStamp() != null
                  ? transCardBean.getTransactionTimeStamp().getTime()
                  : null,
              timeToLive);
      authBatch.add(insertAuthStatementCacheByTransID);

      insertAuthStatementCacheByCardAndSe =
          insertAuthCacheByCardAndSePS.bind(
              authorization.getSeNumber(),
              authorization.isTokenAvailable()
                  ? authorization.getDpan()
                  : authorization.getCardNumber(),
              transCardBean.getApproveDenyCode(),
              "N",
              cardDac6Bean.getAuthTransactionDateTime().getTime(),
              authorization.getTransactionId(),
              transCardBean.getAuthAmountLocal(),
              transCardBean.getAuthAmountUSD(),
              cardDac2Bean.getCacheStringKey(),
              cardDac6Bean.getCacheStringKey(),
              transCardBean.getAuthUniqueIdentifier(),
              authorization.getAuthAmountCurrencyCode(),
              authorization.getVoiceAuthIndicator(),
              authorization.getPosDataCode(),
              authorization.getEciIndicator(),
              authorization.getOriginalMCC(),
              authorization.getCreditWhyDeniedCode(),
              authorization.getFraudWhyDeniedCode(),
              timeToLive);
      authBatch.add(insertAuthStatementCacheByCardAndSe);

      insertAuthStatementCacheBy6DAC =
          insertAuthCacheBy6DACPS.bind(
              (authorization.isTokenAvailable()
                  ? authorization.getDpan()
                  : authorization.getCardNumber()),
              authorization.getAuth6dac(),
              transCardBean.getApproveDenyCode(),
              transCardBean.getAuthUniqueIdentifier(),
              "N",
              authorization.getSeNumber(),
              transCardBean.getAuthAmountUSD(),
              transCardBean.getAuthAmountLocal(),
              transCardBean.getAuthAmountUSD(),
              cardDac2Bean.getCacheStringKey(),
              transCardBean.getCacheStringKey(),
              cardDac6Bean.getAuthTransactionDateTime().getTime(),
              timeToLive);

      authBatch.add(insertAuthStatementCacheBy6DAC);

      insertAuthStatementCacheBy2DAC =
          insertAuthCacheBy2DACPS.bind(
              authorization.isTokenAvailable()
                  ? authorization.getDpan()
                  : authorization.getCardNumber(),
              authorization.getAuth2dac(),
              transCardBean.getApproveDenyCode(),
              transCardBean.getAuthUniqueIdentifier(),
              "N",
              authorization.getSeNumber(),
              transCardBean.getAuthAmountUSD(),
              transCardBean.getAuthAmountLocal(),
              transCardBean.getAuthAmountUSD(),
              cardDac6Bean.getCacheStringKey(),
              transCardBean.getCacheStringKey(),
              cardDac6Bean.getAuthTransactionDateTime().getTime(),
              timeToLive);
      authBatch.add(insertAuthStatementCacheBy2DAC);

      ResultSetFuture accountFuture = session.executeAsync(authBatch);
      Futures.addCallback(
          accountFuture,
          new FutureCallback<ResultSet>() {
            @Override
            public void onSuccess(@Nullable com.datastax.driver.core.ResultSet resultSet) {
              // do nothing

            }

            @Override
            public void onFailure(Throwable throwable) {
              logger.error("Casssandra Insert Failure {} ", throwable.getMessage());
            }
          });
    } catch (Exception e) {
      logger.error("Exception while inserting into Cassandra {} ", e.getMessage());
    }
  }

  public int getCountFromAuthTable(CasAuthTransIdCardCacheBean2 transCardBean) {
    String selectAuthByCasPkey = "select * from auth where cas_pkey=?";
    try {
      ResultSet resultSet =
          session.execute(selectAuthByCasPkey, transCardBean.getAuthUniqueIdentifier());
      return resultSet.getAvailableWithoutFetching();
    } catch (Exception e) {
      return 0;
    }
  }

  public ResultSet getDataFromAuthTable(CasAuthTransIdCardCacheBean2 transCardBean) {
    String selectAuthByCasPkey = "select * from auth where cas_pkey=?";
    try {
      ResultSet resultSet =
          session.execute(selectAuthByCasPkey, transCardBean.getAuthUniqueIdentifier());
      return resultSet;
    } catch (Exception e) {
      return null;
    }
  }

  public int getCountFromAuthByTransIdTable(Authorization authorization) {
    String selectAuthByTransId = "select * from auth_by_trans_id where trans_id=? and cm_15=?";
    try {
      ResultSet resultSet =
          session.execute(
              selectAuthByTransId, authorization.getTransactionId(), authorization.getCardNumber());
      return resultSet.getAvailableWithoutFetching();
    } catch (Exception e) {
      return 0;
    }
  }

  public ResultSet getDataFromAuthByTransIdTable(Authorization authorization) {
    String selectAuthByTransId = "select * from auth_by_trans_id where trans_id=? and cm_15=?";
    try {
      ResultSet resultSet =
          session.execute(
              selectAuthByTransId, authorization.getTransactionId(), authorization.getCardNumber());
      return resultSet;
    } catch (Exception e) {
      return null;
    }
  }

  public int getCountFromAuthByCardAndSeTable(Authorization authorization) {
    String selectAuthByCardAndSe =
        "select * from auth_by_card_and_se where auth_se_no=? and cm_15=? and aprv_deny_cd=?";
    try {
      ResultSet resultSet =
          session.execute(
              selectAuthByCardAndSe,
              authorization.getSeNumber(),
              authorization.getCardNumber(),
              "D");
      return resultSet.getAvailableWithoutFetching();
    } catch (Exception e) {
      return 0;
    }
  }

  public int getCountFromAuthBy6dacAndSeTable(
      Authorization authorization, CasAuthCardAccessCode6CacheBean cardDac6Bean) {
    String selectAuthByCardAndSe =
        "select * from auth_by_6dac_and_se where cm15=? and six_dgt_aprv_cde=? and aprv_deny_cd=?";
    try {
      ResultSet resultSet =
          session.execute(
              selectAuthByCardAndSe,
              authorization.getCardNumber(),
              authorization.getAuth6dac(),
              "D");
      return resultSet.getAvailableWithoutFetching();
    } catch (Exception e) {
      return 0;
    }
  }

  public ResultSet getDataFromAuthBy6dacAndSeTable(
      Authorization authorization, CasAuthCardAccessCode6CacheBean cardDac6Bean) {
    String selectAuthByCardAndSe =
        "select * from auth_by_6dac_and_se where cm15=? and six_dgt_aprv_cde=? and aprv_deny_cd=?";
    try {
      ResultSet resultSet =
          session.execute(
              selectAuthByCardAndSe,
              authorization.getCardNumber(),
              authorization.getAuth6dac(),
              "D");
      return resultSet;
    } catch (Exception e) {
      return null;
    }
  }

  public int getCountFromAuthBy2dacAndSeTable(
      Authorization authorization, CasAuthCardAccessCode2CacheBean cardDac2Bean) {
    String selectAuthByCardAndSe =
        "select * from auth_by_2dac_and_se where cm15=? and two_dgt_aprv_cde=? and aprv_deny_cd=?";
    try {
      ResultSet resultSet =
          session.execute(
              selectAuthByCardAndSe,
              authorization.getCardNumber(),
              authorization.getAuth2dac(),
              "D");
      return resultSet.getAvailableWithoutFetching();
    } catch (Exception e) {
      return 0;
    }
  }

  public ResultSet getDataFromAuthBy2dacAndSeTable(
      Authorization authorization, CasAuthCardAccessCode2CacheBean cardDac2Bean) {
    String selectAuthByCardAndSe =
        "select * from auth_by_2dac_and_se where cm15=? and two_dgt_aprv_cde=? and aprv_deny_cd=?";
    try {
      ResultSet resultSet =
          session.execute(
              selectAuthByCardAndSe,
              authorization.getCardNumber(),
              authorization.getAuth2dac(),
              "D");
      return resultSet;
    } catch (Exception e) {
      return null;
    }
  }
}
