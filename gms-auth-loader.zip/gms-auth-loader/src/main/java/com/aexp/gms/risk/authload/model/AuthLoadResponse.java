package com.aexp.gms.risk.authload.model;

import com.aexp.gmnt.imc.compute.global.IProgramData;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "submissionMatchResponse")
@XmlType(propOrder = {"responseMetaData", "matchStatus"})
@XmlAccessorType(XmlAccessType.FIELD)
public class AuthLoadResponse implements IProgramData {

  private ResponseMetaData responseMetaData;

  public ResponseMetaData getResponseMetaData() {
    return responseMetaData;
  }

  public void setResponseMetaData(ResponseMetaData responseMetaData) {
    this.responseMetaData = responseMetaData;
  }
}
