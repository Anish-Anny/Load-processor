package com.aexp.gms.risk.authload.util;

public interface AuthLoadConstants {

  String ENV_DEPENDENT_PROPS = "env_dependent_props";
  String SEVERITY = "1PSEV";
  String SEV_4 = "4";

  String BOOTSTRAP_SERVERS = "bootstrap.servers";
  String ENABLE_AUTO_COMMIT = "enable.auto.commit";
  String AUTO_COMMIT_INTERVAL_MS = "auto.commit.interval.ms";
  String SESSION_TIMEOUT_MS = "session.timeout.ms";
  String KEY_DESERIALIZER = "key.deserializer";
  String VALUE_DESERIALIZER = "value.deserializer";
  String KEY_SERIALIZER = "key.serializer";
  String VALUE_SERIALIZER = "value.serializer";

  String AUTH_MATCH_KAFKA_TOPIC = "kafka.input.topicname";
  String GROUP_ID = "group.id";
  String KAFKA_TRUSTSTORE_PATH = "kafka.truststore.path";
  String CONSUMER_KEYSTORE_PATH = "consumer.keystore.path";
  String CAS_AUTH_CACHE = "GMSRisk_CACHE_CAS_AUTH";
  String CAS_AUTH_TID_CM_CACHE = "GMS_CAS_AUTH_TID_CM_CACHE_V1";
  String CAS_AUTH_TID_CM_CACHE_V3 = "GMS_CAS_AUTH_TID_CM_CACHE_V3";
  String CAS_AUTH_CM_DAC6_CACHE = "GMS_CAS_AUTH_CM_DAC6_CACHE_V1";
  String CAS_AUTH_CM_DAC2_CACHE = "GMS_CAS_AUTH_CM_DAC2_CACHE_V1";
  String RAM_SE_UNMATCH_AMOUNT_CACHE = "GMS_RAM_SE_UNMATCHED_AMOUNT_CACHE";
  String SE_INDUSTRY_LEVERAGE_CACHE = "SE_INDUSTRY_LEVERAGE_CACHE_V1";
  String RAM_TEMP_ROC_CACHE = "RAM_TEMP_ROC_CACHE";
  String PUBLIC = "PUBLIC";
}
