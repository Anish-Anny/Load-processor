package com.aexp.gms.risk.authload.model;

import com.aexp.gms.imc.risk.rules.vo.values.CasAuthTransIdCardCacheBean;
import java.util.List;

public class CasAuthTransIdCardResponse {

  private List<CasAuthTransIdCardCacheBean> casAuthCacheList = null;

  private ResponseMetaData responseMetaData;

  public List<CasAuthTransIdCardCacheBean> getCacheSummary() {
    return casAuthCacheList;
  }

  public void setCacheSummary(List<CasAuthTransIdCardCacheBean> casAuthCacheList) {
    this.casAuthCacheList = casAuthCacheList;
  }

  public ResponseMetaData getResponseMetaData() {
    return responseMetaData;
  }

  public void setResponseMetaData(ResponseMetaData responseMetaData) {
    this.responseMetaData = responseMetaData;
  }
}
