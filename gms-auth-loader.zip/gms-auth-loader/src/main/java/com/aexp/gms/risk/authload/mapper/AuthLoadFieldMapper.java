package com.aexp.gms.risk.authload.mapper;

import com.aexp.gms.risk.authload.exception.AuthLoadValidationException;
import com.aexp.gms.risk.authload.model.Authorization;
import com.aexp.gms.risk.authload.util.AuthLoadPropertyPlaceholderConfigurer;
import com.aexp.gms.risk.cas.auth.AuthSchema;
import com.aexp.gms.risk.nemo.auth.Context;
import com.aexp.gms.risk.nemo.auth.Df31;
import com.aexp.gms.risk.nemo.auth.Gptn;
import com.aexp.gms.risk.nemo.auth.MergeResult;
import com.aexp.gms.risk.nemo.auth.MtNorm;
import com.aexp.gms.risk.nemo.auth.NemoSchema;
import com.aexp.gms.risk.nemo.auth.Transaction;
import com.aexp.gms.risk.nemo.auth.Workflow;
import java.io.File;
import java.nio.file.Files;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import javax.cache.expiry.CreatedExpiryPolicy;
import javax.cache.expiry.Duration;
import javax.cache.expiry.ExpiryPolicy;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;
import org.springframework.util.StringUtils;

@Component
public class AuthLoadFieldMapper {
  private static final Logger LOGGER = LoggerFactory.getLogger(AuthLoadFieldMapper.class);
  private static final List<String> voiceAuthSourceTypes =
      Collections.unmodifiableList(Arrays.asList("09", "11"));
  private Validator validator;
  private static Map<String, Long> tTLIndustryMap = null;

  static {
    try {
      File file;
      if (System.getProperty("env") != null && System.getProperty("env").equals("e0")) {
        file = ResourceUtils.getFile(System.getProperty("industryTTL.path"));
      } else {

        file =
            ResourceUtils.getFile(
                AuthLoadPropertyPlaceholderConfigurer.getProperty("industryTTL.path"));
      }
      String content = new String(Files.readAllBytes(file.toPath()));

      tTLIndustryMap =
          new ObjectMapper().readValue(content, new TypeReference<Map<String, Long>>() {});
    } catch (Exception e) {
      LOGGER.error("Industry TTL Load ", e);
      tTLIndustryMap = new HashMap<>();
    }
  }

  public AuthLoadFieldMapper() {
    ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
    validator = validatorFactory.getValidator();
  }

  public Authorization map(AuthSchema casAuthBean) throws AuthLoadValidationException {

    boolean overwriteIndicator = false;
    /* boolean overwriteIndicator =
    (casAuthBean != null && casAuthBean.getOverwriteIndicator() != null)
        ? casAuthBean.getOverwriteIndicator()
        : false;*/
    if (casAuthBean != null && casAuthBean.getOverwriteIndicator() != null) {
      overwriteIndicator = casAuthBean.getOverwriteIndicator();
    }

    if (casAuthBean.getCW() == null || casAuthBean.getCW().getTID8583() == null) {
      LOGGER.error("Invalid TID in json request {} ", casAuthBean.toString());
    }

    // Derive Approve Deny Code bases on Cas field LwrcwDadc
    String approveDenyCode = "D";
    String dadc =
        org.apache.commons.lang.StringUtils.trimToEmpty(
            casAuthBean.getCW() == null ? "" : casAuthBean.getCW().getAPPDENY());
    if (dadc.equals("0") || dadc.equals("1") || dadc.equals("6")) approveDenyCode = "A";

    // Derive isToken Available
    boolean isTokenAvailable =
        isTokenAvailable(casAuthBean.getLS() == null ? "" : casAuthBean.getLS().getMOTKCM15());

    try {
      return deriveTTLFromLoad(
          Authorization.builder()
              .transactionId(
                  casAuthBean.getCW() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getCW().getTID8583()))
              .cardNumber(
                  casAuthBean.getIS() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getIS().getLACCT19()))
              .seNumber(
                  casAuthBean.getIS() == null
                      ? ""
                      : StringUtils.trimAllWhitespace(casAuthBean.getIS().getSENUM15()))
              .seCountryCode(casAuthBean.getS3() == null ? "" : casAuthBean.getS3().getTCNTRYX())
              .seIndustryCategoryCode(
                  casAuthBean.getS3() == null ? "" : casAuthBean.getS3().getSBFSCD())
              .authTransactionDate(
                  casAuthBean.getCW() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getCW().getDGOD()))
              .authTransactionTime(
                  casAuthBean.getCW() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getCW().getTMOFDYIN()))
              .authAmountUSD(
                  casAuthBean.getIS() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getIS().getAMOUNT()))
              .authAmountLocal(
                  casAuthBean.getCC() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getCC().getCONVAMT()))
              .authAmountCurrencyCode(
                  casAuthBean.getIS() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getIS().getCRRNTYP()))
              .foreignSpendIndicator(
                  casAuthBean.getAW() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getAW().getFRGNIND()))
              .auth2dac(
                  casAuthBean.getRR() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getRR().getAPPRVLCD()))
              .auth6dac(
                  casAuthBean.getRR() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getRR().getAPRVCD()))
              .casMessageSwipeIndicator(
                  casAuthBean.getCX() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getCX().getMGSTRPCB()))
              .casMessageSwipeCode(
                  casAuthBean.getCC() == null ? "" : casAuthBean.getCC().getMGSTRPCD())
              .transactionApproveDenyCode(approveDenyCode)
              .mcc(
                  casAuthBean.getS3() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getS3().getAMEXMCC()))
              .fraudLossProbability(
                  casAuthBean.getGM() == null
                      ? new Double(0.00)
                      : casAuthBean.getGM().getNGZPRBFB())
              .seType(
                  casAuthBean.getDX() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getDX().getSETYPE()))
              .casLogIdentifier(
                  casAuthBean.getCW() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getCW().getLSEQNO()))
              .ecbCreationTime(
                  casAuthBean.getCW() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getCW().getTRNSDTTM()))
              .julian(
                  casAuthBean.getDX() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getDX().getJULIAN()))
              .voiceAuthIndicator(
                  casAuthBean.getCW() == null
                      ? ""
                      : mapVoiceAuthIndicator(
                          org.apache.commons.lang.StringUtils.trimToEmpty(
                              casAuthBean.getCW().getSRCTYPE())))
              .posDataCode(
                  casAuthBean.getIS() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getIS().getB55PDCAC()))
              .eciIndicator(
                  casAuthBean.getIS() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getIS().getDF61EC1()))
              .originalMCC(
                  casAuthBean.getCC() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getCC().getOMCC()))
              .creditWhyDeniedCode(
                  casAuthBean.getDW() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getDW().getCRWHYDND()))
              .fraudWhyDeniedCode(
                  casAuthBean.getDW() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getDW().getFWDCDE()))
              .dpan(
                  casAuthBean.getLS() == null
                      ? ""
                      : org.apache.commons.lang.StringUtils.trimToEmpty(
                          casAuthBean.getLS().getMOTKCM15()))
              .isTokenAvailable(isTokenAvailable)
              .standIn(casAuthBean.getLS() == null ? "" : casAuthBean.getLS().getSTCNT1())
              .source("CAS")
              .overwriteIndicator(overwriteIndicator)
              .build());
    } catch (Exception ex) {
      LOGGER.error("Exception  : while mapping ", casAuthBean);
      return new Authorization();
    }
  }

  private void validateAuthMatchBean(AuthSchema casAuthBean) throws AuthLoadValidationException {

    StringBuilder errorMessageBuild = new StringBuilder();
    if (casAuthBean != null) {
      Set<ConstraintViolation<AuthSchema>> violations = validator.validate(casAuthBean);
      boolean hasError = false;
      for (ConstraintViolation<AuthSchema> violation : violations) {
        errorMessageBuild.append("Field:");
        errorMessageBuild.append(violation.getPropertyPath());
        errorMessageBuild.append("Message:");
        errorMessageBuild.append(violation.getMessage());
        hasError = true;
      }
      if (hasError) {
        throw new AuthLoadValidationException(errorMessageBuild.toString());
      }
    }
  }

  private boolean isTokenAvailable(String token) {
    boolean isToken = false;
    if (null != token && !"".equals(StringUtils.trimAllWhitespace(token))) {
      isToken = true;
    }
    return isToken;
  }

  private final SimpleDateFormat authorizationDateFormatNemo =
      new SimpleDateFormat("yyyy-MMdd'T'hh:mm:ss.SSS");

  private final SimpleDateFormat casFormatDate = new SimpleDateFormat("MMddyy");
  private final SimpleDateFormat casFormatTime = new SimpleDateFormat("hhmmss");

  public Authorization map(NemoSchema nemoSchema) {

    Transaction transactionInfo = getTransaction(nemoSchema);
    MergeResult mergeResult = getMergeResult(nemoSchema);

    String date = "";
    String time = "";
    Date datetime = new Date();
    try {
      datetime = authorizationDateFormatNemo.parse(transactionInfo.getLocalDateTime());
      date = (casFormatDate.format(datetime));
      time = (casFormatTime.format(datetime));
    } catch (ParseException e) {
      LOGGER.error("Date from Nemo Incorrect {}", transactionInfo.getLocalDateTime());
    }

    boolean is6DAC = false;

    if (mergeResult.getApprovalCode() != null) {
      is6DAC = (mergeResult.getApprovalCode().length() == 6);
    }

    return Authorization.builder()
        .transactionId(
            org.apache.commons.lang.StringUtils.trimToEmpty(mergeResult.getTransactionIdentifier()))
        .cardNumber(
            org.apache.commons.lang.StringUtils.trimToEmpty(
                transactionInfo
                    .getPrimaryAccountNumber())) // As of this field is encrypted NEMO has plans to
        // decrypt it
        .seNumber(
            transactionInfo
                .getCardAcceptorIdentificationCode()) // As of noe Nemo is sending this field but
        // has plans to convert this Amex 10 digit se
        // number
        .seCountryCode(transactionInfo.getAcquirerCountryCode())
        .seIndustryCategoryCode(null) // NEMO does not know how to populate this field
        // .authTransactionDate(AUTH_DATE_FORMATTER.format(instant))
        // .authTransactionTime(AUTH_TIME_FORMATTER.format(instant))
        .authTransactionDate(date)
        .authTransactionTime(time)
        .authAmountUSD("0.00") // NEMO does not know at what stage to populate this
        .authAmountLocal(transactionInfo.getTransactionAmount())
        .authAmountCurrencyCode(transactionInfo.getTransactionCurrencyCode())
        .foreignSpendIndicator(null) // NEMO does not know how to populate this
        .auth2dac(is6DAC ? null : mergeResult.getApprovalCode())
        .auth6dac(is6DAC ? mergeResult.getApprovalCode() : null)
        .casMessageSwipeIndicator(null) // NEMO does not have this info
        .transactionApproveDenyCode("A")
        .mcc(transactionInfo.getMerchantCategoryCode())
        .fraudLossProbability(0.00) // NEMO does not have this info
        .seType(null) // NEMO does not have this info
        .casLogIdentifier(mergeResult.getTransactionIdentifier()) // NEMO does not have this info
        .ecbCreationTime("") // NEMO does not have this info
        .julian("") // NEMO does not have this info
        .voiceAuthIndicator(null) // NEMO does not have this info
        .posDataCode(null) // NEMO does not have this info
        .eciIndicator(null) // NEMO does not have this info
        .originalMCC(null) // NEMO does not have this info
        .creditWhyDeniedCode(null) // NEMO does not have this info
        .fraudWhyDeniedCode(null) // NEMO does not have this info
        .dpan(null) // NEMO does not have this field
        .isTokenAvailable(false) // NEMO does not have DPAN
        .source("NEMO")
        .build();
  }

  public Transaction getTransaction(NemoSchema nemoSchema) {
    Transaction transaction = null;
    Context context = getContext(nemoSchema);
    if (context != null) {
      Gptn gptn = context.getGptn();
      if (gptn != null) {
        MtNorm mtNorm = gptn.getMtNorm();
        if (mtNorm != null) {
          transaction = mtNorm.getTransaction();
        }
      }
    }
    return transaction;
  }

  public Context getContext(NemoSchema nemoSchema) {
    Context context = null;
    if (nemoSchema != null) {
      Workflow workflow = nemoSchema.getWorkflow();
      if (workflow != null) {
        context = workflow.getContext();
        if (context != null) {
          return context;
        }
      }
    }
    return context;
  }

  public MergeResult getMergeResult(NemoSchema nemoSchema) {
    MergeResult mergeResult = null;
    Context context = getContext(nemoSchema);
    if (context != null) {
      Df31 df31 = context.getDf31();
      if (df31 != null) {
        mergeResult = df31.getMergeResult();
      }
    }
    return mergeResult;
  }

  private String mapVoiceAuthIndicator(String input) {

    if (voiceAuthSourceTypes.contains(input)) {
      return "Y";
    } else {
      return "N";
    }
  }

  private static final ExpiryPolicy NEMO_EXPIRY_POLICY =
      new CreatedExpiryPolicy(new Duration(TimeUnit.DAYS, 30));

  private static final ExpiryPolicy CAS_DEFAULT_EXPIRY_POLICY =
      new CreatedExpiryPolicy(new Duration(TimeUnit.DAYS, 10));

  private Authorization deriveTTLFromLoad(Authorization authorization) {
    if ("CAS".equals(authorization.getSource())) {
      if (tTLIndustryMap.get(authorization.getSeIndustryCategoryCode()) != null) {
        authorization.setExpiryPolicy(
            new CreatedExpiryPolicy(
                new Duration(
                    TimeUnit.DAYS,
                    (Long) tTLIndustryMap.get(authorization.getSeIndustryCategoryCode()))));
      } else {
        authorization.setExpiryPolicy(CAS_DEFAULT_EXPIRY_POLICY);
      }
    } else {
      authorization.setExpiryPolicy(NEMO_EXPIRY_POLICY);
    }
    return authorization;
  }
}
