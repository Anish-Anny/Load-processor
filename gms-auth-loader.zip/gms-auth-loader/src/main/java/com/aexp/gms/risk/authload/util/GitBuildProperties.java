package com.aexp.gms.risk.authload.util;

import javax.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

/**
 * Wraps the properties extracted from the git commit information
 *
 * <p>Note this is a small subset of available properties for demo purposes
 */
@Component
@PropertySource(value = {"classpath:git.properties"})
public class GitBuildProperties {

  private static final Logger LOGGER = LoggerFactory.getLogger(GitBuildProperties.class);
  private final String gitBuildTime;
  private final String gitBranch;
  private final String gitCommitId;

  @Autowired
  public GitBuildProperties(
      @Value("${git.build.time}") String gitBuildTime,
      @Value("${git.branch}") String gitBranch,
      @Value("${git.commit.id}") String gitCommitId) {
    this.gitBuildTime = gitBuildTime;
    this.gitBranch = gitBranch;
    this.gitCommitId = gitCommitId;
  }

  public String getGitBuildTime() {
    return gitBuildTime;
  }

  public String getGitBranch() {
    return gitBranch;
  }

  @Override
  public String toString() {
    return "PoCBuildProperties{"
        + "gitBuildTime='"
        + gitBuildTime
        + '\''
        + ", gitBranch='"
        + gitBranch
        + '\''
        + ", gitCommitId='"
        + gitCommitId
        + '\''
        + '}';
  }

  public String getGitCommitId() {
    return gitCommitId;
  }

  @PostConstruct
  public void writeGitCommitInformationToLog() {
    LOGGER.debug("Git commit info: {}", this);
  }
}
