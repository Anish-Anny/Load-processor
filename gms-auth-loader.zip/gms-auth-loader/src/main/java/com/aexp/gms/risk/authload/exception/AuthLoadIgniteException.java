package com.aexp.gms.risk.authload.exception;

/** Created by rmanick on 2/22/2018. */
public class AuthLoadIgniteException extends AuthLoadException {

  private static final long serialVersionUID = 1L;

  public AuthLoadIgniteException() {
    super();
  }

  public AuthLoadIgniteException(String msg, Throwable e) {
    super(msg, e);
  }

  public AuthLoadIgniteException(String message) {
    super(message);
  }

  public AuthLoadIgniteException(Throwable t) {
    super(t);
  }
}
