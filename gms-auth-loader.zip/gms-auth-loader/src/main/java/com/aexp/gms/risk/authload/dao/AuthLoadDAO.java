package com.aexp.gms.risk.authload.dao;

import com.aexp.gms.imc.risk.rules.vo.values.ICacheBean;
import com.aexp.gms.risk.authload.exception.AuthLoadIgniteException;
import com.aexp.gms.risk.authload.exception.AuthLoadSystemException;
import com.aexp.gms.risk.authload.model.Authorization;
import com.aexp.gms.risk.authload.model.CasAuthTransIdCardResponse;
import javax.cache.expiry.ExpiryPolicy;

public interface AuthLoadDAO {

  public boolean startIgnite() throws AuthLoadSystemException;

  public boolean activateIgnite() throws AuthLoadSystemException;

  public boolean getCache() throws AuthLoadSystemException;

  public boolean getCache(String cacheName) throws AuthLoadSystemException;

  public boolean loadCache(ICacheBean bean) throws AuthLoadSystemException, AuthLoadIgniteException;

  public boolean loadCache(String cacheName, ICacheBean bean, ExpiryPolicy expiryPolicy)
      throws AuthLoadSystemException, AuthLoadIgniteException;

  public int getCacheCount(String cacheName) throws AuthLoadSystemException;

  public boolean resetIgniteConnection() throws AuthLoadSystemException;

  public int resetSemaPhore(String semaPhoreName) throws AuthLoadSystemException;

  public CasAuthTransIdCardResponse getCASAuthDataByTid(String transactionId)
      throws AuthLoadSystemException;

  public boolean ifAuthMatchExists(Authorization authorization);

  public void validateCacheVersion();

  public void checkIgniteHealth();
}
