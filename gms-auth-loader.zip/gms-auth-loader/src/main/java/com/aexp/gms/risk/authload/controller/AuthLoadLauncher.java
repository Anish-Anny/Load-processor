package com.aexp.gms.risk.authload.controller;

import com.americanexpress.ea.elf.servlet.ELFFilter;
import com.americanexpress.ea.elf.spring.resttemplate.DefaultHttpClientConfig;
import com.americanexpress.ea.elf.spring.servlet.DefaultSpringWebServerConfig;
import com.americanexpress.ea.elf.tracer.core.util.TracerUtils;
import io.opentracing.Tracer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.cassandra.CassandraDataAutoConfiguration;
import org.springframework.boot.autoconfigure.jms.JmsAutoConfiguration;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;

@Configuration
@EnableAutoConfiguration(
    exclude = {
      KafkaAutoConfiguration.class,
      JmsAutoConfiguration.class,
      CassandraDataAutoConfiguration.class
    })
@ImportResource("classpath:auth-loader-jar-spring-config.xml")
@Import({DefaultSpringWebServerConfig.class, DefaultHttpClientConfig.class})
public class AuthLoadLauncher extends SpringBootServletInitializer {

  private static final Logger logger = LoggerFactory.getLogger(AuthLoadLauncher.class);
  // private static ConfigurableApplicationContext applicationContext = null;

  public static void main(String[] args) {

    SpringApplication.run(AuthLoadLauncher.class, args);

    logger.info("Starting Auth Load API");

    if (args != null && args.length > 0) {
      logger.info("Enumerating jar args:");

      for (String arg : args) {
        logger.info("\t{}", arg);
      }
    }
  }

  @Bean
  public FilterRegistrationBean registerLoggingFilter(ELFFilter elfFilter) {
    FilterRegistrationBean registration = new FilterRegistrationBean(elfFilter);
    registration.addUrlPatterns("/healthcheck");
    registration.setOrder(1);
    return registration;
  }

  @Bean
  public Tracer tracer() {
    return TracerUtils.defaultTracer();
  }
}
