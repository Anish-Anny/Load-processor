package com.aexp.gms.risk.authload.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@EqualsAndHashCode
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AuthCacheKeyBean {

  private String authUniqueIdentifier;
  private String transactionId;
  private String cardNumber;
}
