package com.aexp.gms.risk.authload.util;

import com.aexp.gms.risk.authload.model.Authorization;
import com.aexp.gms.risk.cas.auth.AuthSchema;
import scala.collection.mutable.StringBuilder;

/**
 * Package name to be passed as parameter in constructor. Make this as class level global variable.
 * MerchantLog merchantLog = new
 * MerchantLog(RiskSubmonRulesExecutionProcessor.class.getPackage().getName());
 *
 * <p>Info statements will not have application specific attributes ->
 * LOGGER.info(merchantLog.getCommonLogAttributes() + "|json message == null, returning");
 *
 * <p>Errors from Exception block should be logged with application specific attributes. Exception
 * object passed to LOGGER will print stacktrace ->
 * LOGGER.error(merchantLog.getSpecificLogAttributes("F", "GR100") + "|\"Exception in overall
 * try/catch: \" ",e);
 */
public class AuthLoadLog {
  // Common or Generic attributes
  private String packageName;
  private String transactionResult;
  private String transactionResultCode;
  private String transactionResultSubCode;
  private String placeHolder1;
  private String placeHolder2;

  // Application specific attributes
  private String seNumber;

  private String correlationId = "";
  private String referralCode = "";

  public AuthLoadLog(String packageName) {
    this.packageName = packageName;
  }

  public AuthLoadLog(AuthSchema record) {
    this.packageName = ""; // TODO: implement as paramter

    this.seNumber = record.getIS().getSENUM15();
    if (this.seNumber != null) this.correlationId = record.getCW().getTID8583();
  }

  public void setAppSpecificInfo(Authorization record) {
    this.seNumber = record.getSeNumber();
    if (record.getSeNumber() != null) this.correlationId = record.getTransactionId();
  }

  public void setAppSpecificInfo(String seNumber, String correlationId) {
    this.seNumber = seNumber;
    this.correlationId = correlationId;
  }

  @Override
  public String toString() {

    return String.format(
        "[PackageName=%s|TransactionResult=%s|TransactionResultCode=%s|TransactionResultSubCode=%s|%s|%s]|CorrelationId=%s|SENumber=%s|||ReferralCode=%s|",
        packageName,
        transactionResult,
        transactionResultCode,
        transactionResultSubCode,
        placeHolder1,
        placeHolder2,
        correlationId,
        seNumber,
        referralCode);
  }

  public String getCommonLogAttributes() {
    StringBuilder stringBuild =
        new StringBuilder(1000)
            .append("{\"PackageName\":\"")
            .append(packageName)
            .append("\",")
            .append("\"TransactionResult\":\"")
            .append(transactionResult)
            .append("\",")
            .append("\"TransactionResultCode\":\"")
            .append(transactionResultCode)
            .append("\",")
            .append("\"TransactionResultSubCode\":\"")
            .append(transactionResultSubCode)
            .append("\"CorrelationId\":\"")
            .append(correlationId)
            .append("\",");
    return stringBuild.toString();
  }

  public String getCommonLogAttributes(String transactionResult, String transactionResultCode) {
    StringBuilder stringBuild =
        new StringBuilder(1000)
            .append("{\"PackageName\":\"")
            .append(packageName)
            .append("\",")
            .append("\"TransactionResult\":\"")
            .append(transactionResult)
            .append("\",")
            .append("\"TransactionResultCode\":\"")
            .append(transactionResultCode)
            .append("\",")
            .append("\"TransactionResultSubCode\":\"")
            .append(transactionResultSubCode)
            .append("\",");
    return stringBuild.toString();
  }

  public String getCommonLogAttributes(
      String transactionResult, String transactionResultCode, AuthSchema casAuthBean) {
    StringBuilder stringBuild =
        new StringBuilder(1000)
            .append("{\"PackageName\":\"")
            .append(packageName)
            .append("\",")
            .append("\"TransactionResult\":")
            .append("\"")
            .append(transactionResult)
            .append("\",")
            .append("\"TransactionResultCode\":")
            .append("\"")
            .append(transactionResultCode)
            .append("\",")
            .append("\"TransactionResultSubCode\":")
            .append("\"")
            .append(transactionResultSubCode)
            .append("\",")
            .append("\"CorrelationId\":")
            .append("\"")
            .append(correlationId)
            .append("\",")
            .append("\"CAS_PK\":")
            .append("\"")
            .append(casAuthBean.getCW().getDGOD())
            .append(casAuthBean.getCW().getLSEQNO())
            .append("\",");
    return stringBuild.toString();
  }
}
