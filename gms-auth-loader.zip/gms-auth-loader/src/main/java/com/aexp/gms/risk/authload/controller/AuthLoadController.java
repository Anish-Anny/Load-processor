package com.aexp.gms.risk.authload.controller;

import com.aexp.gms.risk.authload.exception.AuthLoadSystemException;
import com.aexp.gms.risk.authload.exception.AuthLoadValidationException;
import com.aexp.gms.risk.authload.mapper.AuthLoadFieldMapper;
import com.aexp.gms.risk.authload.model.*;
import com.aexp.gms.risk.authload.services.AuthLoadService;
import com.aexp.gms.risk.authload.util.AuthLoadLog;
import com.aexp.gms.risk.authload.util.AuthLoadUtil;
import com.aexp.gms.risk.authload.util.ITier;
import com.aexp.gms.risk.cas.auth.AuthSchema;
import com.aexp.gms.risk.nemo.auth.NemoSchema;
import com.fasterxml.jackson.databind.MapperFeature;
import java.io.IOException;
import java.time.Instant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/gms/v1")
public class AuthLoadController {

  private static final String CLASS_NAME = "AuthLoadController";

  private static AuthLoadService serviceLayer;
  @Autowired private AuthLoadFieldMapper authLoadFieldMapper;
  private static com.fasterxml.jackson.databind.ObjectMapper mapper =
      new com.fasterxml.jackson.databind.ObjectMapper();
  private static final Logger logger = LoggerFactory.getLogger(AuthLoadController.class);
  private AuthLoadLog authLoadLog =
      new AuthLoadLog(AuthLoadController.class.getPackage().getName());

  public AuthLoadController() {}

  @Autowired
  public AuthLoadController(@Qualifier("authLoadServiceImpl") AuthLoadService serviceLayer) {
    logger.debug(
        "{}\"Message\":\"In authLoadServiceImpl constructor, thread id {}\"}",
        authLoadLog.getCommonLogAttributes("S", "GR0032"),
        Thread.currentThread().getId(),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "AuthLoadController");

    this.serviceLayer = serviceLayer;

    logger.debug(
        "{}\"Message\":\"Launched thread\"}",
        authLoadLog.getCommonLogAttributes("S", "GR0001"),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "AuthLoadController");
  }

  @RequestMapping(method = RequestMethod.GET, value = "/authorizations/healthcheck")
  public ResponseEntity checkHealth() {
    return ResponseEntity.status(HttpStatus.OK).body("I am healthy!");
  }

  public AuthLoadService getServiceLayer() {
    return serviceLayer;
  }

  public void setServiceLayer(AuthLoadService serviceLayer) {
    this.serviceLayer = serviceLayer;
  }

  @RequestMapping(
      method = RequestMethod.GET,
      value = "/authorizations/count/{cache_name:.*}",
      produces = "application/json;charset=UTF-8")
  @ResponseBody
  public ResponseEntity getCacheCount(@PathVariable("cache_name") String cacheName) {

    logger.debug(
        "{}\"Message\":\"In getCacheCount, thread id {}\"}",
        authLoadLog.getCommonLogAttributes("S", "GR0003"),
        Thread.currentThread().getId(),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "AuthLoadController");

    CacheSummaryResponse response = null;
    ResponseMetaData responseMetaData = null;
    long startTime = Instant.now().toEpochMilli();

    try {
      response = serviceLayer.getCacheCount(cacheName);
      responseMetaData = new ResponseMetaData();
      responseMetaData.setCode("200");
      responseMetaData.setShortMessage("OK");
      String responseTime = AuthLoadUtil.getAPIResponseTime(startTime);
      responseMetaData.setResponseTime(responseTime);
      response.setResponseMetaData(responseMetaData);
    } catch (AuthLoadSystemException authLoadSystemException) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(
              String.format(
                  "%s-%s",
                  HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                  authLoadSystemException.getMessage()));
    }
    return ResponseEntity.status(HttpStatus.OK).body(response);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/authorizations/resetIgnite")
  public ResponseEntity resetIgniteConnection() {
    logger.debug(
        "{}\"Messae\":\"in resetIgniteConnection, thread id {}\"}",
        authLoadLog.getCommonLogAttributes("S", "GR0024"),
        Thread.currentThread().getId(),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "AuthLoadController");

    try {
      serviceLayer.resetIgniteConnection();
    } catch (AuthLoadSystemException authLoadSystemException) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(
              String.format(
                  "%s-%s",
                  HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                  authLoadSystemException.getMessage()));
    }
    return ResponseEntity.status(HttpStatus.OK).body("Reset Ignite connection");
  }

  @RequestMapping(
      method = RequestMethod.GET,
      value = "/authorizations/resetSemaphore/{semaphore_name:.*}")
  public ResponseEntity resetSempahore(@PathVariable("semaphore_name") String semaphoreName) {
    logger.debug(
        "{}\"Messae\":\"in resetSemaPhore, thread id {}\"}",
        authLoadLog.getCommonLogAttributes("S", "GR0034"),
        Thread.currentThread().getId(),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "AuthLoadController");
    int drainedPermits = 0;
    try {
      drainedPermits = serviceLayer.resetSemaphore(semaphoreName);
    } catch (AuthLoadSystemException authLoadSystemException) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(
              String.format(
                  "%s-%s",
                  HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                  authLoadSystemException.getMessage()));
    }
    return ResponseEntity.status(HttpStatus.OK)
        .body(
            "Reset Semaphore connection Successfull - "
                + semaphoreName
                + " - Drained Permits- "
                + drainedPermits);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/authorizations/activateIgnite")
  public ResponseEntity activateIgniteCluster() {
    logger.debug(
        "{}\"Message\":\"In activateIgniteCluster, thread id {}\"}",
        authLoadLog.getCommonLogAttributes("S", "GR3005"),
        Thread.currentThread().getId(),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "AuthLoadController");

    try {
      serviceLayer.activateIgnite();
    } catch (AuthLoadSystemException authLoadSystemException) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(
              String.format(
                  "%s-%s",
                  HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                  authLoadSystemException.getMessage()));
    }
    return ResponseEntity.status(HttpStatus.OK).body("Activated Ignite connection");
  }

  @RequestMapping(method = RequestMethod.POST, value = "/authorizations")
  public ResponseEntity authorizationLoadRequest(
      @RequestBody String authLoadRequest,
      @RequestHeader(name = "ax-correlation-id", required = false, defaultValue = "")
          String axCorrelationId,
      @RequestHeader(name = "rtf-client-path", required = false, defaultValue = "")
          String rtfClientPath) {
    long startTime = Instant.now().toEpochMilli();
    ResponseMetaData responseMetaData = new ResponseMetaData();
    AuthLoadResponse submissionMatchResponse = new AuthLoadResponse();

    mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);

    try {
      Authorization authorization =
          authLoadFieldMapper.map(mapper.readValue(authLoadRequest, AuthSchema.class));
      authorization.setAxCorrelationId(axCorrelationId);
      authorization.setRtfClientPath(rtfClientPath);
      if (serviceLayer.authLoadRequest(authorization)) {
        responseMetaData.setCode("200");
        responseMetaData.setShortMessage("OK");
      } else {
        responseMetaData.setCode("200");
        responseMetaData.setShortMessage("Matched Record Already Exists");
      }
    } catch (IOException ioException) {
      responseMetaData.setCode("400");
      responseMetaData.setShortMessage("Bad JSON " + ioException.getMessage());
    } catch (AuthLoadValidationException authLoadValidationException) {
      responseMetaData.setCode("400");
      responseMetaData.setShortMessage(
          "Not a Valid input" + authLoadValidationException.getMessage());
    }

    String responseTime = AuthLoadUtil.getAPIResponseTime(startTime);
    responseMetaData.setResponseTime(responseTime);
    submissionMatchResponse.setResponseMetaData(responseMetaData);

    return ResponseEntity.status(HttpStatus.OK).body(submissionMatchResponse);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/authorizationsNemo")
  public ResponseEntity authorizationLoadRequestNemo(@RequestBody String authLoadRequest) {

    long startTime = Instant.now().toEpochMilli();
    ResponseMetaData responseMetaData = new ResponseMetaData();
    AuthLoadResponse submissionMatchResponse = new AuthLoadResponse();

    mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);

    try {
      Authorization authorization =
          authLoadFieldMapper.map(mapper.readValue(authLoadRequest, NemoSchema.class));

      if (serviceLayer.authLoadRequest(authorization)) {
        responseMetaData.setCode("200");
        responseMetaData.setShortMessage("OK");
      } else {
        responseMetaData.setCode("200");
        responseMetaData.setShortMessage("Matched Record Already Exists");
      }
    } catch (IOException ioException) {
      responseMetaData.setCode("400");
      responseMetaData.setShortMessage("Bad JSON " + ioException.getMessage());
    }

    String responseTime = AuthLoadUtil.getAPIResponseTime(startTime);
    responseMetaData.setResponseTime(responseTime);
    submissionMatchResponse.setResponseMetaData(responseMetaData);

    return ResponseEntity.status(HttpStatus.OK).body(submissionMatchResponse);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/authorizations/{transaction_id}")
  public ResponseEntity getAuthDetailsByTID(@PathVariable("transaction_id") String transactionId) {

    logger.debug(
        "{}\"Message\":\"In getAuthDetailsByTID, thread id {}\"}",
        authLoadLog.getCommonLogAttributes("S", "GR0009"),
        Thread.currentThread().getId(),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "AuthLoadController");

    CasAuthTransIdCardResponse response = null;
    ResponseMetaData responseMetaData = null;
    long startTime = Instant.now().toEpochMilli();

    try {
      response = serviceLayer.getAuthDetailsByTID(transactionId);
      responseMetaData = new ResponseMetaData();
      responseMetaData.setCode("200");
      responseMetaData.setShortMessage("OK");
      String responseTime = AuthLoadUtil.getAPIResponseTime(startTime);
      responseMetaData.setResponseTime(responseTime);
      response.setResponseMetaData(responseMetaData);
    } catch (AuthLoadSystemException authLoadSystemException) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(
              String.format(
                  "%s-%s",
                  HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                  authLoadSystemException.getMessage()));
    }
    return ResponseEntity.status(HttpStatus.OK).body(response);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/authorizations/validate/cacheversion")
  public ResponseEntity validateCacheVersion() {

    logger.debug(
        "{}\"Message\":\"In AuthLoadController validate cache, thread id {}\"}",
        authLoadLog.getCommonLogAttributes("S", "GR0012"),
        Thread.currentThread().getId(),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "AuthMatchController");

    ResponseMetaData responseMetaData = new ResponseMetaData();
    responseMetaData.setCode(String.valueOf(HttpStatus.OK.value()));
    responseMetaData.setShortMessage(HttpStatus.OK.getReasonPhrase());

    // Make service layer call
    serviceLayer.validateCacheVersion();

    return ResponseEntity.status(HttpStatus.OK).body(responseMetaData);
  }
}
