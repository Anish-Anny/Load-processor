package com.aexp.gms.risk.authload.model;

import java.util.List;

public class CacheSummaryResponse {

  private List<CacheSummary> cacheSummary = null;

  private ResponseMetaData responseMetaData;

  public List<CacheSummary> getCacheSummary() {
    return cacheSummary;
  }

  public void setCacheSummary(List<CacheSummary> cacheSummary) {
    this.cacheSummary = cacheSummary;
  }

  public ResponseMetaData getResponseMetaData() {
    return responseMetaData;
  }

  public void setResponseMetaData(ResponseMetaData responseMetaData) {
    this.responseMetaData = responseMetaData;
  }
}
