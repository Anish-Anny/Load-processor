package com.aexp.gms.risk.authload.model;

import javax.cache.expiry.ExpiryPolicy;
import lombok.*;

@Builder
@Setter
@Getter
@AllArgsConstructor
@RequiredArgsConstructor
@EqualsAndHashCode
@ToString
public class Authorization {

  private String transactionId;
  private String cardNumber;
  private String seNumber;
  private String seCountryCode;
  private String seIndustryCategoryCode;
  private String authTransactionDate;
  private String authTransactionTime;
  private String authAmountUSD;
  private String authAmountLocal;
  private String authAmountCurrencyCode;
  private String foreignSpendIndicator;
  private String auth2dac;
  private String auth6dac;
  private String casMessageSwipeIndicator;
  private String casMessageSwipeCode;
  private String transactionApproveDenyCode;
  private String mcc;
  private Double fraudLossProbability;
  private String seType;
  private String casLogIdentifier;
  private String ecbCreationTime;
  private String julian;
  private String voiceAuthIndicator;
  private String posDataCode;
  private String eciIndicator;
  private String originalMCC;
  private String creditWhyDeniedCode;
  private String fraudWhyDeniedCode;
  private String dpan;
  private String source;
  private boolean isTokenAvailable;
  private String axCorrelationId;
  private String rtfClientPath;
  private String standIn;
  private ExpiryPolicy expiryPolicy;
  private Boolean overwriteIndicator = new Boolean(false);
}
