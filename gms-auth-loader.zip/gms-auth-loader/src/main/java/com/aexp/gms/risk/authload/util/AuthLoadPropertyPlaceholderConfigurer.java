package com.aexp.gms.risk.authload.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

public class AuthLoadPropertyPlaceholderConfigurer extends PropertyPlaceholderConfigurer {

  private static Map<String, String> propertiesMap;
  private int springSystemPropertiesMode = SYSTEM_PROPERTIES_MODE_FALLBACK;
  /** Constructor, to provide any initialization in the base classes */
  public AuthLoadPropertyPlaceholderConfigurer() {
    super();
  }

  public static void setProperty(String name, String value) {
    propertiesMap = new HashMap<>();
    propertiesMap.put(name, value);
  }

  public static String getProperty(String name) {
    return (String) propertiesMap.get(name);
  }

  @Override
  protected void processProperties(ConfigurableListableBeanFactory beanFactory, Properties props)
      throws BeansException {
    super.processProperties(beanFactory, props);

    propertiesMap = new HashMap<>();
    for (Object key : props.keySet()) {
      String keyStr = key.toString();
      String valueStr = resolvePlaceholder(keyStr, props, springSystemPropertiesMode);
      propertiesMap.put(keyStr, valueStr);
    }
  }
}
