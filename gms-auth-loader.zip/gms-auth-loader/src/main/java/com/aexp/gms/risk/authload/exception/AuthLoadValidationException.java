package com.aexp.gms.risk.authload.exception;

/** Created by rmanick on 2/22/2018. */
public class AuthLoadValidationException extends AuthLoadException {

  private static final long serialVersionUID = 1L;

  public AuthLoadValidationException() {
    super();
  }

  public AuthLoadValidationException(String msg, Throwable e) {
    super(msg, e);
  }

  public AuthLoadValidationException(String message) {
    super(message);
  }

  public AuthLoadValidationException(Throwable t) {
    super(t);
  }
}
