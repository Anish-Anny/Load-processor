package com.aexp.gms.risk.authload.dao;

import com.aexp.gms.imc.risk.rules.vo.keys.CasAuthCardAccessCode2CacheKey;
import com.aexp.gms.imc.risk.rules.vo.keys.CasAuthCardAccessCode6CacheKey;
import com.aexp.gms.imc.risk.rules.vo.keys.CasAuthTransIdCardCacheKey;
import com.aexp.gms.imc.risk.rules.vo.keys.ICacheKey;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode6CacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthTransIdCardCacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthTransIdCardCacheBean2;
import com.aexp.gms.imc.risk.rules.vo.values.ICacheBean;
import com.aexp.gms.risk.authload.exception.AuthLoadIgniteException;
import com.aexp.gms.risk.authload.exception.AuthLoadSystemException;
import com.aexp.gms.risk.authload.model.Authorization;
import com.aexp.gms.risk.authload.model.CasAuthTransIdCardResponse;
import com.aexp.gms.risk.authload.util.AuthLoadConstants;
import com.aexp.gms.risk.authload.util.AuthLoadLog;
import com.aexp.gms.risk.authload.util.ITier;
import com.aexp.gms.risk.authload.util.PropertyLoaderUtils;
import java.lang.annotation.Annotation;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.cache.expiry.ExpiryPolicy;
import org.apache.commons.lang.StringUtils;
import org.apache.ignite.*;
import org.apache.ignite.cache.CachePartialUpdateException;
import org.apache.ignite.cache.CachePeekMode;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.apache.ignite.configuration.CacheConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuthLoadDAOImpl implements AuthLoadDAO {

  private static final String CLASS_NAME = "AuthLoadDAOImpl";
  private static final String CAS_AUTH_CARD_ACCESS_CODE_6_CACHE_QUERY =
      "SELECT COUNT(1) FROM CasAuthCardAccessCode6CacheBean";
  private static final String CAS_AUTH_CARD_ACCESS_CODE_2_CACHE_QUERY =
      "SELECT COUNT(1) FROM CasAuthCardAccessCode2CacheBean";
  private static final String CAS_AUTH_TRANSACTION_ID_CARD_CACHE_QUERY =
      "SELECT COUNT(1) FROM CasAuthTransIdCardCacheBean";
  private static Ignite ignite;
  private static final Logger logger = LoggerFactory.getLogger(AuthLoadDAOImpl.class);

  private AuthLoadLog authLoadLog = new AuthLoadLog(AuthLoadDAOImpl.class.getPackage().getName());

  public AuthLoadDAOImpl() {
    startIgnite();
  }

  @Override
  public boolean startIgnite() {
    logger.info(
        "{}\"Message\":\"Start Ignite\"}",
        authLoadLog.getCommonLogAttributes("S", "GR0001"),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "Start Ignite");

    String igniteConfigFile =
        PropertyLoaderUtils.resolveFileName("imc-ignite-client-config-${env}.xml");
    this.ignite =
        Ignition.getOrStart(
            Ignition.loadSpringBean(
                this.getClass().getClassLoader().getResourceAsStream(igniteConfigFile),
                "ignite.cfg"));
    return true;
  }

  @Override
  public void checkIgniteHealth() {
    Ignite ignite = Ignition.ignite();
    ignite.active();
  }

  /*  public boolean stopIgnite() {
    this.ignite.close();
    return true;
  }*/

  @Override
  public boolean activateIgnite() throws AuthLoadSystemException {
    try {
      ignite.active(true);
    } catch (IgniteException igniteException) {
      throw new AuthLoadSystemException(
          "System Exception while activating Ignite : {} ", igniteException);
    }
    return true;
  }

  @Override
  public int resetSemaPhore(String semaPhoreName) throws AuthLoadSystemException {
    int drainedPermits = 0;
    try {
      IgniteSemaphore igniteSemaphore = ignite.semaphore(semaPhoreName, 1, true, true);
      igniteSemaphore.release();
      drainedPermits = 1;
    } catch (IgniteException igniteException) {
      logger.error("System Exception while clearing Seamaphore Ignite : {} ", igniteException);
      drainedPermits = 0;
    }
    return drainedPermits;
  }

  @Override
  public boolean getCache() throws AuthLoadSystemException {
    try {

      ignite.cache(AuthLoadConstants.CAS_AUTH_CACHE);
    } catch (IgniteException igniteException) {
      throw new AuthLoadSystemException(
          "System Exception while destroying Cache In Ignite : {} ", igniteException);
    }

    return true;
  }

  public Ignite getIgnite() {
    return this.ignite;
  }

  public void setIgnite(Ignite ignite) {
    this.ignite = ignite;
  }

  public IgniteDataStreamer<ICacheKey, ICacheBean> getIgniteStreamer(String cacheName)
      throws AuthLoadSystemException {
    IgniteDataStreamer<ICacheKey, ICacheBean> stmr = null;
    try {
      stmr = ignite.dataStreamer(cacheName);
      stmr.perNodeBufferSize(1024);
      stmr.perNodeParallelOperations(8);
    } catch (IgniteException igniteException) {
      throw new AuthLoadSystemException(
          "System Exception while reading the data streamer from Ignite : {} ", igniteException);
    }
    return stmr;
  }

  public boolean getCache(String cacheName) throws AuthLoadSystemException {
    CacheConfiguration<ICacheKey, ICacheBean> casCacheCfg = new CacheConfiguration<>(cacheName);
    try {

      ignite.getOrCreateCache(casCacheCfg);
    } catch (IgniteException igniteException) {
      throw new AuthLoadSystemException(
          "System Exception while reading cache from Ignite : {} ", igniteException);
    }
    return true;
  }

  @Override
  public boolean loadCache(ICacheBean casBean)
      throws AuthLoadSystemException, AuthLoadIgniteException {

    ExpiryPolicy expiryPolicy = casBean.getExpiryPolicy();
    IgniteCache<ICacheKey, ICacheBean> cache = null;

    try {
      cache = ignite.cache(casBean.getCacheName());
      if (cache != null) {
        cache.withExpiryPolicy(expiryPolicy).put(casBean.getCacheKey(), casBean);
      }
    } catch (Exception e) {
      logger.error("System Exception while reading cache from Ignite", e);

      if (e instanceof CachePartialUpdateException) {
        logger.info(
            "{}\"Message\":\"CachePartialUpdateException, resetting ignite instance\"}",
            authLoadLog.getCommonLogAttributes("S", "GR0004"),
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            "Load Cache");

        resetIgniteConnection();
        getCache(AuthLoadConstants.CAS_AUTH_CACHE);
        cache.withExpiryPolicy(expiryPolicy).put(casBean.getCacheKey(), casBean);
        logger.info(
            "{}\"Message\":\"CachePartialUpdateException, reset ignite successful\"}",
            authLoadLog.getCommonLogAttributes("S", "GR0005"),
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            "Load Cache");

      } else if (e instanceof IgniteException) {
        throw new AuthLoadIgniteException("System Exception while  loading into  Ignite : {} ", e);
      } else {
        throw new AuthLoadSystemException(
            "Unknown Application Exception while  loading into  Ignite");
      }
    }

    return true;
  }

  @Override
  public boolean loadCache(String cacheName, ICacheBean casBean, ExpiryPolicy expiryPolicy)
      throws AuthLoadSystemException, AuthLoadIgniteException {
    IgniteCache<ICacheKey, ICacheBean> cache = null;

    try {
      cache = ignite.cache(cacheName);
      cache.withExpiryPolicy(expiryPolicy).put(casBean.getCacheKey(), casBean);

    } catch (Exception e) {
      if (e instanceof CachePartialUpdateException) {
        logger.info(
            "{}\"Message\":\"CachePartialUpdateException, resetting ignite instance\"}",
            authLoadLog.getCommonLogAttributes("S", "GR0004"),
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            "Load Cache");

        resetIgniteConnection();
        getCache(AuthLoadConstants.CAS_AUTH_CACHE);
        cache.withExpiryPolicy(expiryPolicy).put(casBean.getCacheKey(), casBean);
        logger.info(
            "{}\"Message\":\"CachePartialUpdateException, reset ignite successful\"}",
            authLoadLog.getCommonLogAttributes("S", "GR0005"),
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            "Load Cache");
      } else if (e instanceof IgniteException) {
        throw new AuthLoadIgniteException("System Exception while  loading into  Ignite : {} ", e);
      } else {
        throw new AuthLoadSystemException(
            "Unknown Application Exception while  loading into  Ignite");
      }
    }
    return true;
  }

  @Override
  public int getCacheCount(String cacheName) throws AuthLoadSystemException {
    int count = 0;
    IgniteCache<ICacheKey, ICacheBean> casAuthCache = null;
    logger.debug(
        "{}\"Message\":\"Start Cache count\"}",
        authLoadLog.getCommonLogAttributes("S", "GR0007"),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "Load Cache");
    try {
      casAuthCache = ignite.cache(cacheName);
      count = casAuthCache.size(CachePeekMode.PRIMARY);
      logger.info(
          "{}\"Message\":\"Cache count {}\"}",
          authLoadLog.getCommonLogAttributes("S", "GR0008"),
          count,
          ITier.REQUESTHANDLER,
          CLASS_NAME,
          "Load Cache");
    } catch (IgniteException igniteException) {
      throw new AuthLoadSystemException(
          "System Exception while getting cache from Ignite : {} ", igniteException);
    }
    return count;
  }

  @Override
  public boolean resetIgniteConnection() throws AuthLoadSystemException {
    String igniteConfigFile =
        PropertyLoaderUtils.resolveFileName("imc-ignite-client-config-${env}.xml");
    try {
      ignite.close();
      ignite = null;
      this.ignite =
          Ignition.getOrStart(
              Ignition.loadSpringBean(
                  this.getClass().getClassLoader().getResourceAsStream(igniteConfigFile),
                  "ignite.cfg"));
    } catch (IgniteException igniteException) {
      throw new AuthLoadSystemException(
          "System Exception while loadingg TID cache from bean : {} ", igniteException);
    }

    return true;
  }

  @Override
  public CasAuthTransIdCardResponse getCASAuthDataByTid(String transactionId)
      throws AuthLoadSystemException {

    CasAuthTransIdCardResponse response = new CasAuthTransIdCardResponse();
    CasAuthTransIdCardCacheBean casAuthBean = null;
    List<CasAuthTransIdCardCacheBean> casAuthCacheList = new ArrayList<>();
    SqlFieldsQuery query;

    IgniteCache<Object, Object> igniteCache;
    igniteCache = ignite.cache(AuthLoadConstants.CAS_AUTH_TID_CM_CACHE_V3);
    query =
        new SqlFieldsQuery(
            "SELECT * FROM CASAUTHTRANSIDCARDCACHEBEAN2 where TRANSACTIONID = '"
                + transactionId
                + "'");
    List<List<?>> resultList = igniteCache.query(query.setDistributedJoins(true)).getAll();
    for (List<?> list : resultList) {
      casAuthBean = new CasAuthTransIdCardCacheBean();
      ArrayList<?> next = (ArrayList<?>) resultList.get(0);

      casAuthBean.setTransactionId((String) next.get(0));
      casAuthBean.setCardNumber(
          ((String) next.get(1)).substring(0, 11)
              + StringUtils.repeat("X", ((String) next.get(1)).length() - 11));
      casAuthBean.setApproveDenyCode((String) next.get(2));
      casAuthBean.setAuthAmountUSD((BigDecimal) next.get(3));
      casAuthBean.setRocAuthMatchedFlag((String) next.get(4));
      casAuthBean.setRocAuthMatchedCriteriaId((String) next.get(5));
      casAuthBean.setPersistedFlag((String) next.get(6));

      casAuthBean.setAuthUniqueIdentifier((String) next.get(9));
      casAuthBean.setSeNumber((String) next.get(10));
      casAuthBean.setAuthTransactionDateTime((Date) next.get(11));
      casAuthCacheList.add(casAuthBean);

      //            	casAuthBean.setCardDac6PrimaryKey((String) next.get(7));
      //            	casAuthBean.setCardDac2PrimaryKey((String) next.get(8));

    }

    response.setCacheSummary(casAuthCacheList);

    return response;
  }

  public boolean ifAuthMatchExists(Authorization authorization) {
    boolean isMatchExists = false;
    try {
      IgniteCache<Object, Object> transCardCache =
          ignite.cache(AuthLoadConstants.CAS_AUTH_TID_CM_CACHE_V3);

      CasAuthTransIdCardCacheKey transCardKey =
          new CasAuthTransIdCardCacheKey(
              authorization.getTransactionId(),
              authorization.getCardNumber(),
              authorization.getTransactionApproveDenyCode());

      if (transCardCache.get(transCardKey) != null) {
        isMatchExists = true;
        logger.debug(
            "Record exists in {} : {} , {} , {}",
            AuthLoadConstants.CAS_AUTH_TID_CM_CACHE_V3,
            transCardKey.getTransactionId(),
            transCardKey.getCardNumber(),
            transCardKey.getApproveDenyCode());
      }
    } catch (Exception ex) {
      logger.error(ex.getMessage());
    }
    return isMatchExists;
  }

  @Override
  public void validateCacheVersion() {
    CasAuthTransIdCardCacheBean bean = new CasAuthTransIdCardCacheBean();
    bean.setCardNumber("370000000000200");
    bean.setTransactionId("000000000000200");
    bean.setApproveDenyCode("D");
    CasAuthTransIdCardCacheKey key = (CasAuthTransIdCardCacheKey) bean.getCacheKey();
    logger.debug("AuthLoad - Key Hashcode :{} , Key toString :{} ", key.hashCode(), key.toString());
    IgniteCache<ICacheKey, ICacheBean> cache = ignite.cache("GMS_CAS_AUTH_TID_CM_CACHE_V3");
    cache.put(key, new CasAuthTransIdCardCacheBean2());
    logger.debug(
        "Cache Name : {} ,AuthLoad - Key exists{} ", cache.getName(), cache.containsKey(key));

    logger.debug(
        "Nodes : {} ", ignite.affinity(cache.getName()).mapKeyToPrimaryAndBackups(key).toString());
    logger.debug(
        "Partion number : {} ", Integer.toString(ignite.affinity(cache.getName()).partition(key)));
    Class aClass = CasAuthTransIdCardCacheKey.class;
    logger.debug("Class loader: {} ", aClass.getClassLoader());
    Annotation[] annotations = null;
    logger.debug("Checking annotations");

    try {
      annotations = aClass.getDeclaredField("cardNumber").getDeclaredAnnotations();

    } catch (Exception e) {
      // e.printStackTrace();
      logger.error("No cardNumber", e);
    }

    if (annotations.length == 0) logger.debug("No annotations");

    for (Annotation annotation : annotations) {
      logger.debug("AuthLoad - Annotation type: {} ", annotation.annotationType());
    }

    logger.debug(
        "AuthLoad - Domain Bean version info : TID Cache -{} , TID Cache Key -{} , DAC6 Cache -{} , DAC6 Cache Key -{} ,DAC2 Cache -{}  , DAC2 Cache Key -{} ",
        (new CasAuthTransIdCardCacheBean()).toString(),
        (new CasAuthTransIdCardCacheKey("1|1|1")).toString(),
        (new CasAuthCardAccessCode6CacheBean()).toString(),
        (new CasAuthCardAccessCode6CacheKey("1|1|1")).toString(),
        (new CasAuthCardAccessCode6CacheBean()).toString(),
        (new CasAuthCardAccessCode2CacheKey("1|1|1")).toString());
  }
}
