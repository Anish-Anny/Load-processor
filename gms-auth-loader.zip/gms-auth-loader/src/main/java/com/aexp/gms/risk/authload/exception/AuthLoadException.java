package com.aexp.gms.risk.authload.exception;

/** Created by rmanick on 2/22/2018. */
public class AuthLoadException extends Exception {

  private static final long serialVersionUID = 1L;

  public AuthLoadException() {
    super();
  }

  public AuthLoadException(String msg, Throwable e) {
    super(msg, e);
  }

  public AuthLoadException(String message) {
    super(message);
  }

  public AuthLoadException(Throwable t) {
    super(t);
  }
}
