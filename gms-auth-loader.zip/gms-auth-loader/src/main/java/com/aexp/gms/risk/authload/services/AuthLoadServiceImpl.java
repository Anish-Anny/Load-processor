package com.aexp.gms.risk.authload.services;

import com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode2CacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode6CacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthTransIdCardCacheBean2;
import com.aexp.gms.risk.authload.dao.AuthLoadDAO;
import com.aexp.gms.risk.authload.exception.AuthLoadSystemException;
import com.aexp.gms.risk.authload.model.AuthCacheKeyBean;
import com.aexp.gms.risk.authload.model.Authorization;
import com.aexp.gms.risk.authload.model.CacheSummary;
import com.aexp.gms.risk.authload.model.CacheSummaryResponse;
import com.aexp.gms.risk.authload.model.CasAuthTransIdCardResponse;
import com.aexp.gms.risk.authload.util.AuthLoadConstants;
import com.aexp.gms.risk.authload.util.AuthLoadLog;
import com.aexp.gms.risk.authload.util.AuthLoadUtil;
import com.aexp.gms.risk.authload.util.ITier;
import com.aexp.gms.risk.authload.util.KafkaProducerConfig;
import com.aexp.gms.risk.data.CassandraAuthDAOImpl;
import com.aexp.gms.risk.encrypt.EncryptionServiceImpl;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import scala.collection.mutable.StringBuilder;

// @Component("authMatchServiceImpl")
public class AuthLoadServiceImpl implements AuthLoadService {

  private static final String CLASS_NAME = "AuthLoadServiceImpl";
  private AuthLoadLog authLoadLog =
      new AuthLoadLog(AuthLoadServiceImpl.class.getPackage().getName());
  private final Logger logger = LoggerFactory.getLogger(AuthLoadServiceImpl.class);

  @Value("${cassandraDisableFlag:N}")
  private String cassandraDisableFlag;

  @Value("${encryptionFlag:N}")
  private String encryptionFlag;

  private boolean igniteStarted = false;

  // @Autowired
  private AuthLoadDAO authLoadDAOImpl;

  private CassandraAuthDAOImpl cassandraAuthDAOImpl;

  @Autowired private EncryptionServiceImpl encryptionServiceImpl;

  private KafkaProducerConfig kafkaProducerConfig;

  // private AuthCacheKeyBean authCacheKeyBean;

  public AuthLoadServiceImpl(
      AuthLoadDAO authLoadDAOImpl,
      CassandraAuthDAOImpl cassandraAuthDAOImpl,
      KafkaProducerConfig kafkaProducerConfig) {
    logger.info(
        "{}\"Message\":\"AuthLoadServiceImpl constructor\"}",
        authLoadLog.getCommonLogAttributes("S", "GR5000"),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "AuthLoadServiceImpl");
    this.authLoadDAOImpl = authLoadDAOImpl;
    this.cassandraAuthDAOImpl = cassandraAuthDAOImpl;
    this.kafkaProducerConfig = kafkaProducerConfig;
  }

  @Override
  public boolean activateIgnite() throws AuthLoadSystemException {
    authLoadDAOImpl.activateIgnite();
    return true;
  }

  @Override
  public int resetSemaphore(String semaPhoreName) throws AuthLoadSystemException {
    return authLoadDAOImpl.resetSemaPhore(semaPhoreName);
  }

  @Override
  public CacheSummaryResponse getCacheCount(String cacheName) throws AuthLoadSystemException {
    if (!igniteStarted) authLoadDAOImpl.startIgnite();

    CacheSummaryResponse response = new CacheSummaryResponse();
    CacheSummary cacheSummary = null;
    List<CacheSummary> cacheSummaryList = new ArrayList<CacheSummary>();
    if (cacheName.equals("*")) {
      cacheSummary = new CacheSummary();
      cacheSummary.setCacheName(AuthLoadConstants.CAS_AUTH_TID_CM_CACHE_V3);
      cacheSummary.setCacheCount(
          authLoadDAOImpl.getCacheCount(AuthLoadConstants.CAS_AUTH_TID_CM_CACHE_V3));
      cacheSummaryList.add(cacheSummary);

      cacheSummary = new CacheSummary();
      cacheSummary.setCacheName(AuthLoadConstants.CAS_AUTH_CM_DAC6_CACHE);
      cacheSummary.setCacheCount(
          authLoadDAOImpl.getCacheCount(AuthLoadConstants.CAS_AUTH_CM_DAC6_CACHE));
      cacheSummaryList.add(cacheSummary);

      cacheSummary = new CacheSummary();
      cacheSummary.setCacheName(AuthLoadConstants.CAS_AUTH_CM_DAC2_CACHE);
      cacheSummary.setCacheCount(
          authLoadDAOImpl.getCacheCount(AuthLoadConstants.CAS_AUTH_CM_DAC2_CACHE));
      cacheSummaryList.add(cacheSummary);

    } else {
      cacheSummary = new CacheSummary();
      cacheSummary.setCacheName(cacheName);
      cacheSummary.setCacheCount(authLoadDAOImpl.getCacheCount(cacheName));
      cacheSummaryList.add(cacheSummary);
    }

    response.setCacheSummary(cacheSummaryList);

    return response;
  }

  @Override
  public boolean authLoadRequest(Authorization authorization) {
    long igniteStartTime = 0;

    StringBuilder stringBuild = new StringBuilder(1000);
    /*    LOGGER.info(
            "\"GR5004\":\"In authLoadRequest, TID: {}, isTokenAvailable: {}, VoiceAuthInd: {} , MagStripeIndicator: {}, MagStripeCode: {}, POSDataCode(CardPresentIndicator): {}, Header Request AX-ID: {} , RTF Client Path {}, Source :{}, Stand In {}, SE IND Code {}\"}",
            authorization.getTransactionId() == null ? "NO TID" : authorization.getTransactionId(),
            authorization.isTokenAvailable(),
            authorization.getVoiceAuthIndicator(),
            authorization.getCasMessageSwipeIndicator(),
            authorization.getCasMessageSwipeCode(),
            authorization.getPosDataCode() != null && authorization.getPosDataCode().length() >= 6
                ? authorization.getPosDataCode().charAt(5)
                : "",
            authorization.getAxCorrelationId(),
            authorization.getRtfClientPath(),
            "LB",
            authorization.getStandIn(),
            authorization.getSeIndustryCategoryCode(),
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            "AuthLoadServiceImpl");
    */
    CasAuthTransIdCardCacheBean2 transCardBean = null;
    CasAuthCardAccessCode6CacheBean cardDac6Bean = null;
    CasAuthCardAccessCode2CacheBean cardDac2Bean = null;
    String cardNumberForLogger = null;
    try {
      authLoadLog.setAppSpecificInfo(authorization);
      // Convert json to bean

      if (authorization != null
          && authorization.getCardNumber() != null
          && authorization.getCardNumber().trim().length() >= 11) {
        cardNumberForLogger = authorization.getCardNumber();
        cardNumberForLogger = cardNumberForLogger.substring(2, 11);
      } else {
        cardNumberForLogger = authorization.getCardNumber();
      }

      if (encryptionFlag != null && encryptionFlag.equals("Y")) {
        if (authorization.getCardNumber() != null) {
          authorization.setCardNumber(encryptionServiceImpl.encrypt(authorization.getCardNumber()));
        }
        if (authorization.isTokenAvailable()
            && authorization.getDpan() != null
            && !org.apache.commons.lang.StringUtils.isEmpty(authorization.getDpan())) {
          authorization.setDpan(encryptionServiceImpl.encrypt(authorization.getDpan()));
        }
      }

      // CHECK IF MATCH EXISTS IN CACHE BEFORE LOADING AGAIN
      if (!authLoadDAOImpl.ifAuthMatchExists(authorization)) {

        transCardBean = getTidBean(authorization);
        cardDac6Bean = getCardDac6Bean(authorization);
        cardDac2Bean = getCardDac2Bean(authorization);

        transCardBean.setCardDac2PrimaryKey(cardDac2Bean.getCacheStringKey());
        transCardBean.setCardDac6PrimaryKey(cardDac6Bean.getCacheStringKey());

        cardDac6Bean.setTidCMPrimaryKey(transCardBean.getCacheStringKey());
        cardDac6Bean.setCardDac2PrimaryKey(cardDac2Bean.getCacheStringKey());

        cardDac2Bean.setCardDac6PrimaryKey(cardDac6Bean.getCacheStringKey());
        cardDac2Bean.setTidCMPrimaryKey(transCardBean.getCacheStringKey());
        igniteStartTime = Instant.now().toEpochMilli();
        authLoadDAOImpl.loadCache(
            AuthLoadConstants.CAS_AUTH_TID_CM_CACHE_V3,
            transCardBean,
            authorization.getExpiryPolicy());
        authLoadDAOImpl.loadCache(
            AuthLoadConstants.CAS_AUTH_CM_DAC6_CACHE,
            cardDac6Bean,
            authorization.getExpiryPolicy());
        authLoadDAOImpl.loadCache(
            AuthLoadConstants.CAS_AUTH_CM_DAC2_CACHE,
            cardDac2Bean,
            authorization.getExpiryPolicy());

        stringBuild
            .append("\"Ignite Response time\":\"")
            .append(AuthLoadUtil.getAPIResponseTime(igniteStartTime))
            .append("\"");
        // TID, masked CM, Auth AuthAmount USD, DAC6, DAC2, SE#

        // if overwriteIndicator is true then dont load to cassandra and no pudh to kafka
        secondaryLoadToCassandraAndKafka(
            authorization,
            stringBuild,
            transCardBean,
            cardDac6Bean,
            cardDac2Bean,
            cardNumberForLogger);

      } else {
        logger.info(
            " {}\"Message\":\"Matched Record Exists in Cache !!!\"}",
            authorization.getTransactionId());
        return false;
      }
    } catch (Exception ex) {
      logger.error("\"Message\":\"Ignite exception while loading: {}\"}", ex.getMessage());
      secondaryLoadToCassandraAndKafka(
          authorization,
          stringBuild,
          transCardBean,
          cardDac6Bean,
          cardDac2Bean,
          cardNumberForLogger);
    }
    return true;
  }

  private void secondaryLoadToCassandraAndKafka(
      Authorization authorization,
      StringBuilder stringBuild,
      CasAuthTransIdCardCacheBean2 transCardBean,
      CasAuthCardAccessCode6CacheBean cardDac6Bean,
      CasAuthCardAccessCode2CacheBean cardDac2Bean,
      String cardNumberForLogger) {
    long cassandraStartTime;

    if (!authorization.getOverwriteIndicator()) {
      publishRehydrateToKafka(authorization, transCardBean);

      cassandraStartTime = Instant.now().toEpochMilli();
      loadCassandra(authorization, transCardBean, cardDac6Bean, cardDac2Bean);
      stringBuild
          .append("\"Cassandra Response time\":\"")
          .append(AuthLoadUtil.getAPIResponseTime(cassandraStartTime))
          .append("\"");
    }

    logger.info(
        "GR5005 In SecondaryLoadToCassandraAndKafka TID:{},CM:{},AuthAmountUSD:{},DAC6:{},DAC2:{},SE:{},OverwriterIndicator:{} ,isTokenAvailable: {}, VoiceAuthInd: {} , MagStripeIndicator: {}, MagStripeCode: {}, POSDataCode(CardPresentIndicator): {}, Header Request AX-ID: {} , RTF Client Path {}, Source :{}, Stand In {}, SE IND Code {} ,Response Times: {}",
        transCardBean.getTransactionId(),
        cardNumberForLogger,
        transCardBean.getAuthAmountUSD(),
        cardDac6Bean.getAuth6Dac(),
        cardDac2Bean.getAuth2Dac(),
        transCardBean.getSeNumber(),
        authorization.getOverwriteIndicator(),
        authorization.isTokenAvailable(),
        authorization.getVoiceAuthIndicator(),
        authorization.getCasMessageSwipeIndicator(),
        authorization.getCasMessageSwipeCode(),
        authorization.getPosDataCode() != null && authorization.getPosDataCode().length() >= 6
            ? authorization.getPosDataCode().charAt(5)
            : "",
        authorization.getAxCorrelationId(),
        authorization.getRtfClientPath(),
        "LB",
        authorization.getStandIn(),
        authorization.getSeIndustryCategoryCode(),
        stringBuild.toString());
  }

  private void publishRehydrateToKafka(
      Authorization authorization, CasAuthTransIdCardCacheBean2 transCardBean) {
    // publish to kafka starts here
    AuthCacheKeyBean authCacheKeyBean;
    authCacheKeyBean =
        AuthCacheKeyBean.builder()
            .authUniqueIdentifier(transCardBean.getAuthUniqueIdentifier())
            .cardNumber(authorization.getCardNumber())
            .transactionId(authorization.getTransactionId())
            .build();

    sendCachesToKafka(authCacheKeyBean, authorization);
  }

  private void loadCassandra(
      Authorization authorization,
      CasAuthTransIdCardCacheBean2 transCardBean,
      CasAuthCardAccessCode6CacheBean cardDac6Bean,
      CasAuthCardAccessCode2CacheBean cardDac2Bean) {

    try {
      if (cassandraDisableFlag != null && !cassandraDisableFlag.equals("Y")) {
        cassandraAuthDAOImpl.insertAuthorization(
            authorization, transCardBean, cardDac6Bean, cardDac2Bean);
      }

    } catch (Exception ex) {
      logger.error("\"Message\":\"Cassandra exception while loading: {}\"}", ex.getMessage());
    }
  }

  @Override
  public boolean resetIgniteConnection() throws AuthLoadSystemException {
    authLoadDAOImpl.resetIgniteConnection();
    return true;
  }

  @Override
  public CasAuthTransIdCardResponse getAuthDetailsByTID(String transactionId)
      throws AuthLoadSystemException {

    return authLoadDAOImpl.getCASAuthDataByTid(transactionId);
  }

  @Override
  public void validateCacheVersion() {
    authLoadDAOImpl.validateCacheVersion();
  }

  @Override
  public void checkIgniteHealth() {
    authLoadDAOImpl.checkIgniteHealth();
  }

  private String deriveCardNumber(Authorization authorization) {
    return authorization.isTokenAvailable()
        ? authorization.getDpan()
        : authorization.getCardNumber();
  }

  private Date deriveAuthorizationDate(Authorization authorization) {
    Date date = null;

    StringBuilder authorizationDate = new StringBuilder(15);
    DateTimeFormatter.ofPattern("MMddyy HHmmss");

    DateTimeFormatter casRtlAuthrizationDateFormat = DateTimeFormatter.ofPattern("yyyyMMdd HHmmss");

    if (StringUtils.isEmpty(
        org.apache.commons.lang.StringUtils.trimToEmpty(authorization.getAuthTransactionDate()))) {
      date = new Date();
    } else {

      authorizationDate.append(authorization.getAuthTransactionDate());
      authorizationDate.append(" ");
      authorizationDate.append(
          StringUtils.isEmpty(
                  org.apache.commons.lang.StringUtils.trimToEmpty(
                      authorization.getAuthTransactionTime()))
              ? "000000"
              : authorization.getAuthTransactionTime());

      try {
        LocalDateTime localDatetime =
            LocalDateTime.parse(authorizationDate.toString(), casRtlAuthrizationDateFormat);
        ZonedDateTime mst = localDatetime.atZone(ZoneId.of("America/Phoenix"));
        date = Date.from(mst.toInstant());
      } catch (Exception e) {
        logger.info(
            "{}\"Message\":\"Invalid date-\" {} ,\"TID\" :\"{}\"}",
            authLoadLog.getCommonLogAttributes("S", "GR5017"),
            authorizationDate.toString(),
            authorization.getTransactionId(),
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            "AuthLoadServiceImpl");

        date = new Date();
      }
    }
    return date;
  }

  private BigDecimal deriveAuthAmountUSD(Authorization authorization) {

    return new BigDecimal(
            StringUtils.isEmpty(authorization.getAuthAmountUSD())
                ? "0.00"
                : authorization.getAuthAmountUSD())
        .setScale(2, RoundingMode.CEILING);
  }

  public CasAuthTransIdCardCacheBean2 getTidBean(Authorization authorization) {

    CasAuthTransIdCardCacheBean2 cacheBean = new CasAuthTransIdCardCacheBean2();
    cacheBean.setCardNumber(deriveCardNumber(authorization));
    cacheBean.setTransactionId(authorization.getTransactionId());
    cacheBean.setAuthAmountUSD(deriveAuthAmountUSD(authorization));
    cacheBean.setRocAuthMatchedFlag("N");
    cacheBean.setApproveDenyCode(authorization.getTransactionApproveDenyCode());
    cacheBean.setVoiceAuthIndicator(authorization.getVoiceAuthIndicator());
    cacheBean.setPosDataCode(authorization.getPosDataCode());
    cacheBean.setEciIndicator(authorization.getEciIndicator());
    cacheBean.setMccMerchant(authorization.getOriginalMCC());
    cacheBean.setCreditDeniedcode(authorization.getCreditWhyDeniedCode());
    cacheBean.setFraudDeniedCode(authorization.getFraudWhyDeniedCode());
    cacheBean.setAuthAmountCurrencyCode(authorization.getAuthAmountCurrencyCode());
    cacheBean.setAuthAmountLocal(
        deriveLocalAmountFromForeignAmount(
            authorization.getAuthAmountCurrencyCode(),
            authorization.getAuthAmountLocal(),
            cacheBean.getAuthAmountUSD()));

    cacheBean.setAuthTransactionDateTime(deriveAuthorizationDate(authorization));
    cacheBean.setSeNumber(authorization.getSeNumber());
    cacheBean.setAuthUniqueIdentifier(deriveAuthUniqueIdentifier(authorization));
    if (authorization.getEcbCreationTime() != null
        && org.apache.commons.lang.StringUtils.isNotEmpty(authorization.getEcbCreationTime())) {
      cacheBean.setTransactionTimeStamp(
          AuthLoadUtil.getDateFromString(
              authorization.getEcbCreationTime(), AuthLoadUtil.TRANSACTION_DATE_TIME_FORMAT));
    }

    return cacheBean;
  }

  private String deriveAuthUniqueIdentifier(Authorization authorization) {
    String authIdentifier = "";

    if (authorization.getSource().equals("CAS")) {
      authIdentifier =
          AuthLoadUtil.getCASPKey(
              authorization.getEcbCreationTime(),
              authorization.getJulian(),
              authorization.getCasLogIdentifier());
    } else {
      // NEMO UNIQUE ID
      authIdentifier = authorization.getTransactionId();
    }
    return authIdentifier;
  }

  public CasAuthCardAccessCode6CacheBean getCardDac6Bean(Authorization authorization) {
    CasAuthCardAccessCode6CacheBean cacheBean = new CasAuthCardAccessCode6CacheBean();
    cacheBean.setCardNumber(deriveCardNumber(authorization));
    cacheBean.setAuth6Dac(authorization.getAuth6dac());
    cacheBean.setApproveDenyCode(authorization.getTransactionApproveDenyCode());
    cacheBean.setAuthAmountUSD(deriveAuthAmountUSD(authorization));
    cacheBean.setAuthAmountCurrencyCode(authorization.getAuthAmountCurrencyCode());
    cacheBean.setAuthAmountLocal(
        deriveLocalAmountFromForeignAmount(
            authorization.getAuthAmountCurrencyCode(),
            authorization.getAuthAmountLocal(),
            cacheBean.getAuthAmountUSD()));

    cacheBean.setAuthTransactionDateTime(deriveAuthorizationDate(authorization));
    cacheBean.setSeNumber(authorization.getSeNumber());
    cacheBean.setAuthUniqueIdentifier(deriveAuthUniqueIdentifier(authorization));
    return cacheBean;
  }

  public CasAuthCardAccessCode2CacheBean getCardDac2Bean(Authorization authorization) {

    CasAuthCardAccessCode2CacheBean cacheBean = new CasAuthCardAccessCode2CacheBean();

    cacheBean.setCardNumber(deriveCardNumber(authorization));
    cacheBean.setAuth2Dac(authorization.getAuth2dac());
    cacheBean.setApproveDenyCode(authorization.getTransactionApproveDenyCode());
    cacheBean.setAuthAmountUSD(deriveAuthAmountUSD(authorization));
    cacheBean.setAuthAmountCurrencyCode(authorization.getAuthAmountCurrencyCode());
    cacheBean.setAuthAmountLocal(
        deriveLocalAmountFromForeignAmount(
            authorization.getAuthAmountCurrencyCode(),
            authorization.getAuthAmountLocal(),
            cacheBean.getAuthAmountUSD()));

    cacheBean.setAuthTransactionDateTime(deriveAuthorizationDate(authorization));
    cacheBean.setSeNumber(authorization.getSeNumber());
    cacheBean.setAuthUniqueIdentifier(deriveAuthUniqueIdentifier(authorization));
    return cacheBean;
  }

  private void sendCachesToKafka(AuthCacheKeyBean authCacheKeyBean, Authorization authorization) {
    try {
      this.kafkaProducerConfig.publishForRehydrate(authCacheKeyBean, authorization);
    } catch (Exception e) {
      logger.error(
          "{}\"Message\":\"sendCachesToKafka Error {}\"} ",
          authLoadLog.getCommonLogAttributes("S", "GR5012"),
          e.getMessage(),
          e);
    }
  }

  /**
   * This method will derive the local amount for RAM from CAS field of Foreign Transaction Amount
   */
  private BigDecimal deriveLocalAmountFromForeignAmount(
      String currency, String foreignTransactionAmount, BigDecimal usDollarAmount) {

    BigDecimal localAmount = null;

    boolean isUSDTransaction = org.apache.commons.lang.StringUtils.equals("USD", currency);

    if (StringUtils.isEmpty(
        org.apache.commons.lang.StringUtils.trimToEmpty(foreignTransactionAmount))) {
      if (isUSDTransaction) {
        localAmount = usDollarAmount;
      } else {
        localAmount = new BigDecimal("0.00");
      }
    } else if ((new BigDecimal(foreignTransactionAmount)).compareTo(BigDecimal.ZERO) == 0) {
      if (isUSDTransaction) {
        localAmount = usDollarAmount;
      } else {
        localAmount = new BigDecimal("0.00");
      }

    } else {
      localAmount = new BigDecimal(foreignTransactionAmount);
    }
    return localAmount;
  }
}
