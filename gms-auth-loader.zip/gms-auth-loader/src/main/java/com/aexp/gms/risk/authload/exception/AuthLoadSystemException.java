package com.aexp.gms.risk.authload.exception;

/** Created by rmanick on 2/22/2018. */
public class AuthLoadSystemException extends AuthLoadException {

  private static final long serialVersionUID = 1L;

  public AuthLoadSystemException() {
    super();
  }

  public AuthLoadSystemException(String msg, Throwable e) {
    super(msg, e);
  }

  public AuthLoadSystemException(String message) {
    super(message);
  }

  public AuthLoadSystemException(Throwable t) {
    super(t);
  }
}
