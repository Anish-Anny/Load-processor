package com.aexp.gms.risk.authload.test.solace;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

/** Created by Ramanathan Manickam on 02/15/2018 */
public class CASMessageProducer {
  private static Logger logger = LoggerFactory.getLogger(CASMessageProducer.class);

  private JmsTemplate jmsTemplate;

  public static void main(String[] args) throws JMSException {
    System.setProperty("spring.profiles.active", "e0");
    ClassPathXmlApplicationContext context =
        new ClassPathXmlApplicationContext(new String[] {"applicationContext-solaceConfig.xml"});
    CASMessageProducer producer = (CASMessageProducer) context.getBean("messageProducer");
    // ClassPathXmlApplicationContext context =
    //    new ClassPathXmlApplicationContext(new String[]
    // {"applicationContext-solaceConfig-dedicated.xml"});
    // CASMessageProducer producer = (CASMessageProducer) context.getBean("messageProducer1");

    for (int i = 0; i < 1; i++) {
      producer.sendMessages(i);
    }
    context.close();
  }

  public void sendMessages(int i) throws JMSException {
    getJmsTemplate()
        .send(
            new MessageCreator() {
              @Override
              public Message createMessage(Session session) throws JMSException {
                String jsonValue =
                    "{\n"
                        + "\"lwrcw_7etrid\": \"000000000000200\",\n"
                        + "\"lwrisoact\": \"370700000000200\",\n"
                        + "\"lwrisoaid\": \"9429531213\",\n"
                        + "\"cr41tcntry2\": \"US\",\n"
                        + "\"cr41wwic\": \"RET\",\n"
                        + "\"lwrdgod\": \"101112\",\n"
                        + "\"lwrdtim\": \"100000\",\n"
                        + "\"lwrisoamt\": \"200.44\",\n"
                        + "\"lwrcc_7kfrc\": \"10.99\",\n"
                        + "\"lwrisocur\": \"USD\",\n"
                        + "\"lwraw_frgnind\": \"1\",\n"
                        + "\"lwrrr_kapc\": \"14\",\n"
                        + "\"lwrrr_7dap6\": \"123456\",\n"
                        + "\"lwrcx_mgstrpcd\": \"1\",\n"
                        + "\"lwrcw_dadc\": \"8\",\n"
                        + "\"cr41mcc\": \"5555\",\n"
                        + "\"lwrgm_zprobfb\": 0.657,\n"
                        + "\"lwrdx_7ksep\": \"I\",\n"
                        + "\"lwrcw_7dlog\":\"12345678\",\n"
                        + "    \"lwrcw_ecbcret\":\"55555555\",\n"
                        + "    \"lwrdx_7kjdd\":\"A0\",\n"
                        + "\"lwrsorc\":\"Y\",\n"
                        + "\"lwrisfld22\" :\"990000033332\",\n"
                        + "\"lwrisdf61eci1\" :\"05\",\n"
                        + "\"lwrcc_7komcc\" :\"4404\",\n"
                        + "\"lwrdw_cwdcde\":\"C46\",\n"
                        + "\"lwrdw_fwdcde\" :\"F41\"\n"
                        + "}";
                logger.info(" {}Before Sending JSON -->{}", jsonValue);

                // Message message = session.createTextMessage();
                Message message = session.createTextMessage(jsonValue);
                logger.info("After Sending message -->");

                return message;
              }
            });
  }

  public JmsTemplate getJmsTemplate() {
    return jmsTemplate;
  }

  public void setJmsTemplate(JmsTemplate jmsTemplate) {
    this.jmsTemplate = jmsTemplate;
  }
}
