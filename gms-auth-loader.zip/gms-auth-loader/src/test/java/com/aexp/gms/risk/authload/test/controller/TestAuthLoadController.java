package com.aexp.gms.risk.authload.test.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.aexp.gms.risk.authload.controller.AuthLoadController;
import com.aexp.gms.risk.authload.dao.AuthLoadDAOImpl;
import com.aexp.gms.risk.authload.exception.AuthLoadSystemException;
import com.aexp.gms.risk.authload.mapper.AuthLoadFieldMapper;
import com.aexp.gms.risk.authload.model.AuthLoadResponse;
import com.aexp.gms.risk.authload.model.CasAuthTransIdCardResponse;
import com.aexp.gms.risk.authload.services.AuthLoadServiceImpl;
import com.aexp.gms.risk.authload.test.dao.IgniteServerNode;
import com.aexp.gms.risk.authload.util.KafkaProducerConfig;
import com.aexp.gms.risk.data.CassandraAuthDAOImpl;
import org.apache.ignite.Ignite;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class TestAuthLoadController {
  public static final String authLoadRequest =
      "{\"CW\":{\"TID8583\":\"005608580204571\",\"DGOD\":\"20190214\",\"TMOFDYIN\":\"094834\",\"APPDENY\":\"5\",\"LSEQ_NO\":\"141\",\"TRNSDTTM\":\"2019-02-14 16:00:52:503\"},"
          + "\"IS\":{\"LACCT19\":\"376661014352006\",\"AMOUNT\":\"363.21\",\"SE_NUM15\":\"6318724044\",\"CRRNTYP\":\"USD\"},"
          + "\"CC\":{\"CONV_AMT\":\"363.21\",\"OMCC\":\"4494\"},\"RR\":{\"APPRVLCD\":\"DA\",\"APRVCD\":\"DAC98\"},"
          + "\"DX\":{\"JULIAN\":\"158\"},"
          + "\"S3\":{\"AMEXMCC\":\"5555\",\"TCNTRYX\":\"US\",\"S_BFS_CD\":\"RET\"},"
          + "\"AW\":{\"FRGNIND\":\"1\"},"
          + "\"GM\":{\"NGZPRBFB\":0.657}}";

  private static Ignite serverIgnite = null;
  public static final String axCorrelationId = null;
  public static final String rtfClientPath = null;
  @Mock AuthLoadFieldMapper authLoadFieldMapper;
  @InjectMocks AuthLoadController authLoadController;
  AuthLoadServiceImpl authLoadServiceImpl;
  private AuthLoadDAOImpl authLoadDAOImpl;
  AuthLoadResponse submissionMatchResponse = new AuthLoadResponse();
  private KafkaProducerConfig kafkaProducerConfig;
  private CassandraAuthDAOImpl cassandraAuthDAOImpl;

  @Before
  public void setupMock() throws AuthLoadSystemException {
    System.setProperty("log4j.configurationFile", "gmsrisk-authmatch-processor-log4j.xml");
    System.setProperty("env", "test");
    System.setProperty("spring.profiles.active", "e0");
    System.setProperty("IGNITE_REST_START_ON_CLIENT", "true");
    System.setProperty("data-center", "ipc1");
    MockitoAnnotations.initMocks(this);
    if (serverIgnite == null) {
      System.out.println("Starting Ignite server");
      serverIgnite = new IgniteServerNode("ignite-config-server.xml").getIgnite();
    }
    authLoadDAOImpl = new AuthLoadDAOImpl();
    cassandraAuthDAOImpl = new CassandraAuthDAOImpl();
    authLoadFieldMapper = new AuthLoadFieldMapper();
    String producerBootstrapServers = "ecpkafka-dev.aexp.com:4492";
    String kafkaTopic = "SharedKafka2_41140955_RocAuthMatchResults";
    String keySerializer = "org.apache.kafka.common.serialization.StringSerializer";
    String valueSerializer = "org.apache.kafka.common.serialization.StringSerializer";
    String keystore = "src/test/resources/svc.41140955.dev.aexp.jks";
    String keystorePassword = "amex100";

    kafkaProducerConfig =
        new KafkaProducerConfig(
            producerBootstrapServers,
            kafkaTopic,
            keySerializer,
            valueSerializer,
            keystore,
            keystorePassword);
    authLoadServiceImpl =
        new AuthLoadServiceImpl(authLoadDAOImpl, cassandraAuthDAOImpl, kafkaProducerConfig);
    authLoadController = new AuthLoadController(authLoadServiceImpl);
  }

  @Test
  public void testAuthorizationLoadRequest() throws AuthLoadSystemException {
    try {

      ResponseEntity responseEntity =
          authLoadController.authorizationLoadRequest(
              authLoadRequest, axCorrelationId, rtfClientPath);
      assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
      assertNotNull(responseEntity.getBody());
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  // @Test
  public void testauthorizationLoadRequestNemo() {
    String authLoadRequest =
        "{\r\n"
            + "\"workflow\": {\r\n"
            + "\"context\": {\r\n"
            + "\"gptn\": {\r\n"
            + "\"mt_norm\": {\r\n"
            + "\"transaction\": {\r\n"
            + "\"card_acceptor_identification_code\": \"4105493688\",\r\n"
            + "\"acquirer_country_code\": \"840\",\r\n"
            + "\"merchant_category_code\": \"7380\",\r\n"
            + "\"local_date_time\": \"2019-0619T12:23:45.000\",\r\n"
            + "\"transaction_amount\": \"000000002163\",\r\n"
            + "\"primary_account_number\": \"371100000001724\",\r\n"
            + "\"transaction_currency_code\": \"840\"\r\n"
            + "}\r\n"
            + "},\r\n"
            + "\"mt_par\": {\r\n"
            + "\"parsed_msg\": {\r\n"
            + "\"card_acceptor_country_code\": null\r\n"
            + "}\r\n"
            + "}\r\n"
            + "},\r\n"
            + "\"df31\": {\r\n"
            + "\"merge_result\": {\r\n"
            + "\"approval_code\": \"104962\",\r\n"
            + "\"transaction_identifier\": \"000029561977911\",\r\n"
            + "\"transaction_approve_deny_code\" : \"A\"\r\n"
            + "}\r\n"
            + "}\r\n"
            + "}\r\n"
            + "}\r\n"
            + "}\r\n"
            + "";

    ResponseEntity responseEntity =
        authLoadController.authorizationLoadRequestNemo(authLoadRequest);
    assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    assertNotNull(responseEntity.getBody());
  }

  @Test
  public void testGetAuthDetailsByTID() {
    ResponseEntity responseEntity = authLoadController.getAuthDetailsByTID("005608580204571");
    CasAuthTransIdCardResponse response = (CasAuthTransIdCardResponse) responseEntity.getBody();
    assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    assertNotNull(responseEntity.getBody());
  }

  @Test
  public void testGetCacheCount() {
    ResponseEntity responseEntity = authLoadController.getCacheCount("*");
    assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    assertNotNull(responseEntity.getBody());
  }

  @Test
  public void testResetSempahore() {
    ResponseEntity responseEntity = authLoadController.resetSempahore("Sempahore");
    assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    assertTrue(
        responseEntity.getBody().toString().contains("Reset Semaphore connection Successfull"));
  }

  @Test
  public void testResetIgniteConnection() {
    ResponseEntity responseEntity = authLoadController.resetIgniteConnection();
    assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    assertEquals(responseEntity.getBody().toString(), "Reset Ignite connection");
  }

  @Test
  public void testActivateIgniteCluster() {
    ResponseEntity responseEntity = authLoadController.activateIgniteCluster();
    assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    assertEquals(responseEntity.getBody().toString(), "Activated Ignite connection");
  }

  @Test
  public void testValidateCacheVersion() {
    ResponseEntity responseEntity = authLoadController.validateCacheVersion();
    assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    assertNotNull(responseEntity.getBody());
  }
}
