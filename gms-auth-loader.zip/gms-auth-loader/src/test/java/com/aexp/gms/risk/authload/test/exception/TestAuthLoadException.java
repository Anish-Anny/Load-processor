package com.aexp.gms.risk.authload.test.exception;

import com.aexp.gms.risk.authload.exception.AuthLoadException;
import org.junit.Assert;
import org.junit.Test;

public class TestAuthLoadException {

  @Test
  public void testAuthMatchException() {
    AuthLoadException exception = new AuthLoadException();
    Assert.assertNotNull(exception);
  }

  @Test
  public void testAuthMatchExceptionWithMessage() {
    AuthLoadException exception = new AuthLoadException("Error caught");
    Assert.assertNotNull(exception);
  }

  @Test
  public void testAuthMatchExceptionMessageAndTrhowable() {
    AuthLoadException exception = new AuthLoadException("Error caught", new Throwable());
    Assert.assertNotNull(exception);
  }

  @Test
  public void testAuthMatchExceptionThrowable() {
    AuthLoadException exception = new AuthLoadException(new Throwable());
    Assert.assertNotNull(exception);
  }
}
