package com.aexp.gms.risk.authload.test;

import static org.junit.Assert.assertTrue;

import com.fasterxml.jackson.databind.JsonNode;
import com.github.fge.jackson.JsonLoader;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.core.report.ProcessingMessage;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import com.github.fge.jsonschema.main.JsonValidator;
import java.io.File;
import java.io.IOException;
import org.junit.Assert;
import org.junit.Test;

/** Created by rmanick on 3/1/2018. */
public class CASAuthJSONSchemaValidationTest {

  @Test
  public void givenInvalidInput_whenValidating_thenInvalidMessage()
      throws ProcessingException, IOException {
    ClassLoader classLoader = getClass().getClassLoader();
    File schemaFile = new File(classLoader.getResource("schema/auth-schema.json").getFile());
    File jsonFile = new File(classLoader.getResource("data/cas/invalidMessage.json").getFile());

    final JsonNode data = JsonLoader.fromFile(jsonFile);
    final JsonNode schema = JsonLoader.fromFile(schemaFile);

    final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
    JsonValidator validator = factory.getValidator();

    ProcessingReport report = validator.validate(schema, data);
    Assert.assertFalse(report.isSuccess());
  }

  @Test
  public void givenInvalidInput_whenValidating_thenInvalidMCC()
      throws ProcessingException, IOException {
    ClassLoader classLoader = getClass().getClassLoader();
    File schemaFile = new File(classLoader.getResource("schema/auth-schema.json").getFile());
    File jsonFile = new File(classLoader.getResource("data/cas/invalidmaxsizeMCC.json").getFile());

    final JsonNode data = JsonLoader.fromFile(jsonFile);
    final JsonNode schema = JsonLoader.fromFile(schemaFile);

    final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
    JsonValidator validator = factory.getValidator();

    ProcessingReport report = validator.validate(schema, data);
    Assert.assertFalse(report.isSuccess());

    ProcessingMessage message = report.iterator().next();
    Assert.assertEquals(message.asJson().get("instance").get("pointer").asText(), "/S3/AMEXMCC");
    assertTrue(message.asJson().get("message").asText().contains("maximum allowed"));
  }

  @Test
  public void givenInvalidInput_whenValidating_thenInvalidDataTypeTID()
      throws ProcessingException, IOException {
    ClassLoader classLoader = getClass().getClassLoader();
    File schemaFile = new File(classLoader.getResource("schema/auth-schema.json").getFile());
    File jsonFile = new File(classLoader.getResource("data/cas/invaliddatatypetid.json").getFile());

    final JsonNode data = JsonLoader.fromFile(jsonFile);
    final JsonNode schema = JsonLoader.fromFile(schemaFile);

    final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
    JsonValidator validator = factory.getValidator();

    ProcessingReport report = validator.validate(schema, data);
    Assert.assertFalse(report.isSuccess());

    ProcessingMessage message = report.iterator().next();
    Assert.assertEquals(message.asJson().get("instance").get("pointer").asText(), "/CW/TID8583");
    assertTrue(message.asJson().get("message").asText().contains("instance type"));
  }

  @Test
  public void givenInvalidInput_whenValidating_thenInvalidMaxSizeCardNumber()
      throws ProcessingException, IOException {
    ClassLoader classLoader = getClass().getClassLoader();
    File schemaFile = new File(classLoader.getResource("schema/auth-schema.json").getFile());
    File jsonFile =
        new File(classLoader.getResource("data/cas/invalidmaxsizecardnumber.json").getFile());

    final JsonNode data = JsonLoader.fromFile(jsonFile);
    final JsonNode schema = JsonLoader.fromFile(schemaFile);

    final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
    JsonValidator validator = factory.getValidator();

    ProcessingReport report = validator.validate(schema, data);
    Assert.assertFalse(report.isSuccess());

    ProcessingMessage message = report.iterator().next();
    Assert.assertEquals(message.asJson().get("instance").get("pointer").asText(), "/IS/LACCT19");
    assertTrue(message.asJson().get("message").asText().contains("maximum allowed"));
  }

  @Test
  public void givenInvalidInput_whenValidating_thenInvalidMaxSizeSeNumber()
      throws ProcessingException, IOException {
    ClassLoader classLoader = getClass().getClassLoader();
    File schemaFile = new File(classLoader.getResource("schema/auth-schema.json").getFile());
    File jsonFile =
        new File(classLoader.getResource("data/cas/invalidmaxsizesenumber.json").getFile());

    final JsonNode data = JsonLoader.fromFile(jsonFile);
    final JsonNode schema = JsonLoader.fromFile(schemaFile);

    final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
    JsonValidator validator = factory.getValidator();

    ProcessingReport report = validator.validate(schema, data);
    Assert.assertFalse(report.isSuccess());

    ProcessingMessage message = report.iterator().next();
    Assert.assertEquals(message.asJson().get("instance").get("pointer").asText(), "/IS/SE_NUM15");
    assertTrue(message.asJson().get("message").asText().contains("maximum allowed"));
  }

  @Test
  public void givenInvalidInput_whenValidating_thenInvalidMaxSizeCountryCode()
      throws ProcessingException, IOException {
    ClassLoader classLoader = getClass().getClassLoader();
    File schemaFile = new File(classLoader.getResource("schema/auth-schema.json").getFile());
    File jsonFile =
        new File(classLoader.getResource("data/cas/invalidmaxsizesecountrycode.json").getFile());

    final JsonNode data = JsonLoader.fromFile(jsonFile);
    final JsonNode schema = JsonLoader.fromFile(schemaFile);

    final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
    JsonValidator validator = factory.getValidator();

    ProcessingReport report = validator.validate(schema, data);
    Assert.assertFalse(report.isSuccess());

    ProcessingMessage message = report.iterator().next();
    Assert.assertEquals(message.asJson().get("instance").get("pointer").asText(), "/S3/TCNTRYX");
    assertTrue(message.asJson().get("message").asText().contains("maximum allowed"));
  }

  @Test
  public void givenInvalidInput_whenValidating_thenInvalidMaxSizeSeIndustryCode()
      throws ProcessingException, IOException {
    ClassLoader classLoader = getClass().getClassLoader();
    File schemaFile = new File(classLoader.getResource("schema/auth-schema.json").getFile());
    File jsonFile =
        new File(classLoader.getResource("data/cas/invalidmaxsizeseindustrycode.json").getFile());

    final JsonNode data = JsonLoader.fromFile(jsonFile);
    final JsonNode schema = JsonLoader.fromFile(schemaFile);

    final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
    JsonValidator validator = factory.getValidator();

    ProcessingReport report = validator.validate(schema, data);
    Assert.assertFalse(report.isSuccess());

    ProcessingMessage message = report.iterator().next();
    Assert.assertEquals(message.asJson().get("instance").get("pointer").asText(), "/S3/S_BFS_CD");
    assertTrue(message.asJson().get("message").asText().contains("maximum allowed"));
  }

  @Test
  public void givenInvalidInput_whenValidating_thenInvalidDataTypeCardNumber()
      throws ProcessingException, IOException {
    ClassLoader classLoader = getClass().getClassLoader();
    File schemaFile = new File(classLoader.getResource("schema/auth-schema.json").getFile());
    File jsonFile =
        new File(classLoader.getResource("data/cas/invaliddatatypecardnumber.json").getFile());

    final JsonNode data = JsonLoader.fromFile(jsonFile);
    final JsonNode schema = JsonLoader.fromFile(schemaFile);

    final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
    JsonValidator validator = factory.getValidator();

    ProcessingReport report = validator.validate(schema, data);
    Assert.assertFalse(report.isSuccess());

    ProcessingMessage message = report.iterator().next();
    Assert.assertEquals(message.asJson().get("instance").get("pointer").asText(), "/IS/LACCT19");
    assertTrue(message.asJson().get("message").asText().contains("instance type"));
  }

  @Test
  public void givenValidInput_whenValidatingSchemaFile_thenValid()
      throws ProcessingException, IOException {

    ClassLoader classLoader = getClass().getClassLoader();
    File schemaFile = new File(classLoader.getResource("schema/auth-schema.json").getFile());
    File jsonFile = new File(classLoader.getResource("data/cas/validMessage.json").getFile());

    final JsonNode data = JsonLoader.fromFile(jsonFile);
    final JsonNode schema = JsonLoader.fromFile(schemaFile);

    final JsonSchemaFactory factory = JsonSchemaFactory.byDefault();
    JsonValidator validator = factory.getValidator();

    ProcessingReport report = validator.validate(schema, data);
    Assert.assertTrue(report.isSuccess());
  }
}
