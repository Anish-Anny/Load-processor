package com.aexp.gms.risk.authload.test.util;

import static pl.pojo.tester.api.FieldPredicate.includeAllFields;
import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import com.aexp.gms.risk.authload.model.AuthCacheKeyBean;
import com.aexp.gms.risk.authload.model.Authorization;
import com.aexp.gms.risk.authload.util.AuthLoadPropertyPlaceholderConfigurer;
import com.aexp.gms.risk.authload.util.GitBuildProperties;
import com.aexp.gms.risk.authload.util.ITier;
import com.aexp.gms.risk.authload.util.KafkaProducerConfig;
import com.aexp.gms.risk.authload.util.LoggingUtility;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.junit.Test;
import pl.pojo.tester.api.assertion.Method;

public class ITierTest {

  @Test
  public void testITier() {
    ITier iTier = new ITier();
  }

  @Test
  public void testAuthLoadPropertyPlaceholderConfigurer() {
    final Class<?> cacheSynchup = AuthLoadPropertyPlaceholderConfigurer.class;

    assertPojoMethodsFor(cacheSynchup, includeAllFields(cacheSynchup))
        .testing(Method.CONSTRUCTOR)
        .quickly()
        .areWellImplemented();
    AuthLoadPropertyPlaceholderConfigurer authLoadPropertyPlaceholderConfigurer =
        new AuthLoadPropertyPlaceholderConfigurer();
  }

  @Test
  public void testGitBuildProperties() {

    final Class<?> cacheSynchup = GitBuildProperties.class;

    assertPojoMethodsFor(cacheSynchup, includeAllFields(cacheSynchup))
        .testing(Method.CONSTRUCTOR, Method.GETTER)
        .quickly()
        .areWellImplemented();
    /*    String gitBranch = "";
    String gitBuildTime = "";
    String gitCommitId = "";
    GitBuildProperties gitBuildProperties =new GitBuildProperties(gitBranch, gitBuildTime, gitCommitId);
       gitBuildProperties.getGitBranch();
       gitBuildProperties.getGitBuildTime();
       gitBuildProperties.getGitCommitId();*/
    // ToStringVerifier.forClass(GitBuildProperties.class).withClassName(NameStyle.SIMPLE_NAME);
  }

  @Test
  public void testloggingUtility() {
    LoggingUtility.debug("Test");
    LoggingUtility.error("Test");
    LoggingUtility.info("Test");
    LoggingUtility.trace("Test");
  }

  @Test
  public void testkafkaProducerConfig() throws JsonProcessingException {
    String producerBootstrapServers = "ecpkafka-dev.aexp.com:4492";
    String kafkaTopic = "SharedKafka2_41140955_RocAuthMatchResults";
    String keySerializer = "org.apache.kafka.common.serialization.StringSerializer";
    String valueSerializer = "org.apache.kafka.common.serialization.StringSerializer";
    String keystore = "src/test/resources/svc.41140955.dev.aexp.jks";
    String keystorePassword = "amex100";
    KafkaProducerConfig kafkaProducerConfig =
        new KafkaProducerConfig(
            producerBootstrapServers,
            kafkaTopic,
            keySerializer,
            valueSerializer,
            keystore,
            keystorePassword);
    kafkaProducerConfig.init();
    AuthCacheKeyBean authCacheKeyBean = new AuthCacheKeyBean();
    Authorization authorization = new Authorization();
    kafkaProducerConfig.publishForRehydrate(authCacheKeyBean, authorization);
  }

  @Test
  public void testpropertyUtils() {
    AuthLoadPropertyPlaceholderConfigurer propertyUtils =
        new AuthLoadPropertyPlaceholderConfigurer();
    AuthLoadPropertyPlaceholderConfigurer.setProperty("env", "e0");
    AuthLoadPropertyPlaceholderConfigurer.getProperty("e0");
  }
}
