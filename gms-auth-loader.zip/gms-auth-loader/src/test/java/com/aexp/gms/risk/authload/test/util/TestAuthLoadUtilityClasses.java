package com.aexp.gms.risk.authload.test.util;

import static org.junit.Assert.assertNotNull;

import com.aexp.gms.risk.authload.exception.AuthLoadSystemException;
import com.aexp.gms.risk.authload.util.AuthLoadLog;
import com.aexp.gms.risk.authload.util.PropertyLoaderUtils;
import com.aexp.gms.risk.cas.auth.AW;
import com.aexp.gms.risk.cas.auth.AuthSchema;
import com.aexp.gms.risk.cas.auth.CC;
import com.aexp.gms.risk.cas.auth.CW;
import com.aexp.gms.risk.cas.auth.DX;
import com.aexp.gms.risk.cas.auth.IS;
import com.aexp.gms.risk.cas.auth.RR;
import com.aexp.gms.risk.cas.auth.S3;
import com.fasterxml.jackson.databind.MapperFeature;
import org.junit.Before;
import org.junit.Test;

public class TestAuthLoadUtilityClasses {

  private com.fasterxml.jackson.databind.ObjectMapper mapper =
      new com.fasterxml.jackson.databind.ObjectMapper();
  String authLoadRequest = null;
  // private static Ignite serverIgnite = null;
  @Before
  public void setupMock() throws AuthLoadSystemException {
    System.setProperty("log4j.configurationFile", "gmsrisk-authmatch-processor-log4j.xml");
    System.setProperty("env", "test");
    System.setProperty("spring.profiles.active", "e0");
    System.setProperty("data-center", "ipc1");
    // System.setProperty("IGNITE_REST_START_ON_CLIENT", "true");
    /* if (serverIgnite == null) {
      System.out.println("Starting Ignite server");
      serverIgnite = new IgniteServerNode("ignite-config-server.xml").getIgnite();
    }*/
    authLoadRequest =
        "{\r\n"
            + "	\"CW\":{\r\n"
            + "		\"TID8583\": \"377857026280400\",\r\n"
            + "		\"DGOD\": \"20200224\",\r\n"
            + "		\"TMOFDYIN\": \"193959\",\r\n"
            + "		\"APPDENY\": \"0\",\r\n"
            + "		\"LSEQ_NO\":\"1217667471\",\r\n"
            + "		\"TRNSDTTM\":\"2019-02-21-00:08:00.793\"\r\n"
            + "		\r\n"
            + "	},\r\n"
            + "    \"IS\": {\r\n"
            + "		\"LACCT19\": \"377857026280400\",\r\n"
            + "		\"SE_NUM15\": \"9764113205\",\r\n"
            + "		\"AMOUNT\": \"870.81\",\r\n"
            + "		\"DF61EC1\" :\"08\",\r\n"
            + "		\"CRRNTYP\": \"ADH\",\r\n"
            + "		\"B55PDCAC\" :\"990102033339\"\r\n"
            + "\r\n"
            + "	},\r\n"
            + "	\"S3\": {\r\n"
            + "		\"TCNTRYX\": \"AE\",\r\n"
            + "		\"S_BFS_CD\": \"502\",\r\n"
            + "		\"AMEXMCC\": \"5309\"\r\n"
            + "	},\r\n"
            + "	\"CC\": {\r\n"
            + "		\"CONV_AMT\": \"870.81\",\r\n"
            + "		\"OMCC\" :\"4447\",\r\n"
            + "		\"MGSTRPCB\": \"0\"\r\n"
            + "	},\r\n"
            + "\r\n"
            + "	\"RR\": {\r\n"
            + "		\"APPRVLCD\": \"80\",\r\n"
            + "		\"APRVCD\": \"800000\"\r\n"
            + "	},\r\n"
            + "\r\n"
            + "	\"DX\": {\r\n"
            + "		\"SE_TYPE\": \"A\",\r\n"
            + "		\"JULIAN\":\"123\"\r\n"
            + "	},\r\n"
            + "\r\n"
            + "\r\n"
            + "	\"DW\": {\r\n"
            + "		\"CRWHYDND\":\"C67\",\r\n"
            + "		\"FWDCDE\" :\"F47\"\r\n"
            + "	},\r\n"
            + "\r\n"
            + "\r\n"
            + "	\"AW\": {\r\n"
            + "		\"FRGNIND\": \"1\"\r\n"
            + "	},\r\n"
            + "\r\n"
            + "\r\n"
            + "	\"GM\": {\r\n"
            + "		\"NGZPRBFB\": 0\r\n"
            + "	},\r\n"
            + "\r\n"
            + "	\"LS\": {\r\n"
            + "		\"MOTKCM15\":\"\"\r\n"
            + "	}\r\n"
            + "\r\n"
            + "\r\n"
            + "\r\n"
            + "\r\n"
            + "\r\n"
            + "}\r\n"
            + "";

    mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
  }

  @Test
  public void testToString() throws Exception {
    AuthLoadLog authLoadLog = new AuthLoadLog(mapper.readValue(authLoadRequest, AuthSchema.class));
    assertNotNull(authLoadLog.toString());
  }

  @Test
  public void testGetCommonLogAttributes() throws Exception {
    AuthLoadLog authLoadLog = new AuthLoadLog(mapper.readValue(authLoadRequest, AuthSchema.class));
    assertNotNull(authLoadLog.getCommonLogAttributes());
  }

  @Test
  public void testGetCommonLogAttributesWithArgs() throws Exception {
    AuthLoadLog authLoadLog = new AuthLoadLog(mapper.readValue(authLoadRequest, AuthSchema.class));
    assertNotNull(authLoadLog.getCommonLogAttributes("S", "GR3005"));
  }

  @Test
  public void testGetCommonLogAttributesWithThreeArgs() throws Exception {
    AuthLoadLog authLoadLog = new AuthLoadLog(mapper.readValue(authLoadRequest, AuthSchema.class));
    AuthSchema casAuthBean = new AuthSchema();
    AW aw = new AW();
    aw.setFRGNIND("1");
    casAuthBean.setAW(aw);

    CC cc = new CC();
    cc.setCONVAMT("563.92");
    // cc.setMGSTRPCD(mGSTRPCD);
    cc.setOMCC("4494");
    casAuthBean.setCC(cc);

    CW cw = new CW();
    cw.setAPPDENY("6");
    cw.setDGOD("20190211");
    cw.setLSEQNO("310");
    //  cw.setSRCTYPE(sRCTYPE);
    cw.setTID8583("005681103215275");
    cw.setTMOFDYIN("094834");
    cw.setTRNSDTTM("2020-09-08 16:00:52:503");
    casAuthBean.setCW(cw);

    DX dx = new DX();
    dx.setJULIAN("837");
    casAuthBean.setDX(dx);

    IS is = new IS();
    is.setAMOUNT("563.92");
    is.setLACCT19("376661207886008");
    is.setCRRNTYP("USD");
    is.setSENUM15("1030009096");
    casAuthBean.setIS(is);

    RR rr = new RR();
    rr.setAPPRVLCD("DA");
    rr.setAPRVCD("DAC98");
    casAuthBean.setRR(rr);

    S3 s3 = new S3();
    s3.setAMEXMCC("5555");
    s3.setSBFSCD("RET");
    s3.setTCNTRYX("US");
    casAuthBean.setS3(s3);

    assertNotNull(authLoadLog.getCommonLogAttributes("S", "GR3005", casAuthBean));
  }

  @Test
  public void testLoadProperties() throws Exception {
    PropertyLoaderUtils propertyLoaderUtils = new PropertyLoaderUtils();
    assertNotNull(propertyLoaderUtils.loadProperties("cassandra-connection-e0.properties"));
  }

  @Test
  public void testMergeProperties() throws Exception {
    PropertyLoaderUtils propertyLoaderUtils = new PropertyLoaderUtils();
    assertNotNull(
        propertyLoaderUtils.mergeProperties(
            "cassandra-connection-e0.properties", "cassandra-connection-e1.properties"));
  }
}
