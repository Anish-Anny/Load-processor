package com.aexp.gms.risk.authload.test.exception;

import com.aexp.gms.risk.authload.exception.AuthLoadSystemException;
import org.junit.Assert;
import org.junit.Test;

public class TestAuthLoadSystemException {
  @Test
  public void testAuthMatchException() {
    AuthLoadSystemException exception = new AuthLoadSystemException();
    Assert.assertNotNull(exception);
  }

  @Test
  public void testAuthMatchExceptionWithMessage() {
    AuthLoadSystemException exception = new AuthLoadSystemException("Error caught");
    Assert.assertNotNull(exception);
  }

  @Test
  public void testAuthMatchExceptionMessageAndTrhowable() {
    AuthLoadSystemException exception =
        new AuthLoadSystemException("Error caught", new Throwable());
    Assert.assertNotNull(exception);
  }

  @Test
  public void testAuthMatchExceptionThrowable() {
    AuthLoadSystemException exception = new AuthLoadSystemException(new Throwable());
    Assert.assertNotNull(exception);
  }
}
