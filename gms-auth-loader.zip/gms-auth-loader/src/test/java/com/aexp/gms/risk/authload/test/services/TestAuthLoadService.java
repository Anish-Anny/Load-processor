package com.aexp.gms.risk.authload.test.services;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.aexp.gms.risk.authload.controller.AuthLoadController;
import com.aexp.gms.risk.authload.dao.AuthLoadDAOImpl;
import com.aexp.gms.risk.authload.exception.AuthLoadSystemException;
import com.aexp.gms.risk.authload.mapper.AuthLoadFieldMapper;
import com.aexp.gms.risk.authload.model.Authorization;
import com.aexp.gms.risk.authload.model.CacheSummary;
import com.aexp.gms.risk.authload.model.CasAuthTransIdCardResponse;
import com.aexp.gms.risk.authload.services.AuthLoadServiceImpl;
import com.aexp.gms.risk.authload.test.dao.IgniteServerNode;
import com.aexp.gms.risk.authload.util.AuthLoadConstants;
import com.aexp.gms.risk.authload.util.AuthLoadLog;
import com.aexp.gms.risk.authload.util.KafkaProducerConfig;
import com.aexp.gms.risk.data.CassandraAuthDAOImpl;
import com.fasterxml.jackson.databind.MapperFeature;
import org.apache.ignite.Ignite;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.context.ApplicationContext;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestAuthLoadService {

  private static ApplicationContext applicationContext = null;
  private AuthLoadLog authMatchLog =
      new AuthLoadLog(AuthLoadController.class.getPackage().getName());

  private KafkaProducerConfig kafkaProducerConfig;
  private static AuthLoadServiceImpl serviceLayer;

  @Mock KafkaConsumer<String, String> consumer;

  @Mock ConsumerRecords<String, String> records;

  AuthLoadServiceImpl authLoadServiceImpl;

  @Mock CassandraAuthDAOImpl cassandraAuthDAOImpl;

  @Mock AuthLoadDAOImpl authLoadDAOImpl;

  @Mock AuthLoadFieldMapper authLoadFieldMapper;

  Authorization authorization = new Authorization();

  private static com.fasterxml.jackson.databind.ObjectMapper mapper =
      new com.fasterxml.jackson.databind.ObjectMapper();
  private static Ignite serverIgnite = null;

  @Before
  public void setupMock() throws AuthLoadSystemException {
    System.setProperty("log4j.configurationFile", "gmsrisk-authmatch-processor-log4j.xml");
    System.setProperty("env", "test");
    System.setProperty("spring.profiles.active", "e0");
    System.setProperty("data-center", "ipc1");
    System.setProperty("encryptionFlag", "true");
    System.setProperty("IGNITE_REST_START_ON_CLIENT", "true");

    MockitoAnnotations.initMocks(this);
    authorization = getAuthThorization();
    authLoadFieldMapper = new AuthLoadFieldMapper();
    authLoadServiceImpl =
        new AuthLoadServiceImpl(authLoadDAOImpl, cassandraAuthDAOImpl, kafkaProducerConfig);

    if (serverIgnite == null) {
      System.out.println("Starting Ignite server");
      serverIgnite = new IgniteServerNode("ignite-config-server.xml").getIgnite();
    }
  }

  /* @After
  public void cleanUp() {
    stopIgnite();
  }*/

  @Test
  public void testActivateIgnite() throws AuthLoadSystemException {
    assertTrue(authLoadServiceImpl.activateIgnite());
  }

  @Test
  public void testResetSemaphore() throws AuthLoadSystemException {
    assertEquals(authLoadServiceImpl.resetSemaphore("*"), 0);
  }

  @Test
  public void testResetIgniteConnection() throws AuthLoadSystemException {
    assertTrue(authLoadServiceImpl.resetIgniteConnection());
  }

  @Test
  public void testgetAllCacheCount() throws AuthLoadSystemException {
    assertTrue(authLoadServiceImpl.getCacheCount("*").getCacheSummary().size() > 0);
    for (CacheSummary cacheSummary : authLoadServiceImpl.getCacheCount("*").getCacheSummary()) {
      assertTrue(cacheSummary.getCacheCount() >= 0);
    }
  }

  @Test
  public void testCacheCount() throws AuthLoadSystemException {
    CacheSummary cacheSummaryForTidCache =
        authLoadServiceImpl
            .getCacheCount(AuthLoadConstants.CAS_AUTH_TID_CM_CACHE_V3)
            .getCacheSummary()
            .get(0);
    CacheSummary cacheSummaryForDac2Cache =
        authLoadServiceImpl
            .getCacheCount(AuthLoadConstants.CAS_AUTH_CM_DAC6_CACHE)
            .getCacheSummary()
            .get(0);
    CacheSummary cacheSummaryForDac6ache =
        authLoadServiceImpl
            .getCacheCount(AuthLoadConstants.CAS_AUTH_CM_DAC2_CACHE)
            .getCacheSummary()
            .get(0);
    assertTrue(cacheSummaryForTidCache.getCacheCount() >= 0);
    assertTrue(cacheSummaryForDac2Cache.getCacheCount() >= 0);
    assertTrue(cacheSummaryForDac6ache.getCacheCount() >= 0);
  }

  @Test
  public void testAuthLoadRequest() throws Exception {
    authLoadServiceImpl.authLoadRequest(authorization);
    CasAuthTransIdCardResponse casAuthTransIdCardResponse =
        authLoadServiceImpl.getAuthDetailsByTID(authorization.getTransactionId());
    if (casAuthTransIdCardResponse != null) {
      assertEquals(
          casAuthTransIdCardResponse.getCacheSummary().get(0).getCardNumber(),
          authorization.getCardNumber());
      assertEquals(
          casAuthTransIdCardResponse.getCacheSummary().get(0).getSeNumber(),
          authorization.getSeNumber());
      assertEquals(
          casAuthTransIdCardResponse.getCacheSummary().get(0).getAuthAmountUSD(),
          authorization.getAuthAmountUSD());
    }
  }

  @Test
  public void testAuthLoadRequestNemo() throws Exception {
    String authLoadRequest =
        "{\r\n"
            + "	\"workflow\": {\r\n"
            + "		\"context\": {\r\n"
            + "			\"gptn\": {\r\n"
            + "				\"mt_norm\": {\r\n"
            + "					\"transaction\": {\r\n"
            + "						\"card_acceptor_identification_code\": \"4105493688\",\r\n"
            + "						\"acquirer_country_code\": \"840\",\r\n"
            + "						\"merchant_category_code\": \"7380\",\r\n"
            + "						\"local_date_time\": \"2019-0619T12:23:45.000\",\r\n"
            + "						\"transaction_amount\": \"000000002163\",\r\n"
            + "						\"primary_account_number\": \"377000000001934\",\r\n"
            + "						\"transaction_currency_code\": \"840\"\r\n"
            + "					}\r\n"
            + "				},\r\n"
            + "				\"mt_par\": {\r\n"
            + "					\"parsed_msg\": {\r\n"
            + "						\"card_acceptor_country_code\": null\r\n"
            + "					}\r\n"
            + "				}\r\n"
            + "			},\r\n"
            + "			\"df31\": {\r\n"
            + "				\"merge_result\": {\r\n"
            + "					\"approval_code\": \"234174\",\r\n"
            + "					\"transaction_identifier\": \"000029561977074\"\r\n"
            + "				}\r\n"
            + "			}\r\n"
            + "		}\r\n"
            + "	}\r\n"
            + "}";

    mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
    /*authLoadServiceImpl.authLoadRequest(
    authLoadFieldMapper.map(mapper.readValue(authLoadRequest, NemoSchema.class)));*/
    CasAuthTransIdCardResponse casAuthTransIdCardResponse =
        authLoadServiceImpl.getAuthDetailsByTID("000029561977074");
    if (casAuthTransIdCardResponse != null) {
      assertEquals(
          casAuthTransIdCardResponse.getCacheSummary().get(0).getCardNumber(), "371000000000201");
      assertEquals(casAuthTransIdCardResponse.getCacheSummary().get(0).getSeNumber(), "9429531213");
      assertEquals(
          casAuthTransIdCardResponse.getCacheSummary().get(0).getAuthAmountUSD(), "200.44");
    }
  }

  @Test
  public void testgetAuthDetailsByTID() throws AuthLoadSystemException {
    authLoadServiceImpl.authLoadRequest(authorization);
    CasAuthTransIdCardResponse authDetailsByTID =
        authLoadServiceImpl.getAuthDetailsByTID(authorization.getTransactionId());
  }

  @Test
  public void testgetValidateCacheVersion() {
    authLoadServiceImpl.validateCacheVersion();
  }

  @Test
  public void testCheckIgniteHealth() {
    authLoadServiceImpl.checkIgniteHealth();
  }

  /*public void stopIgnite() {
    authLoadDAOImpl.stopIgnite();
  }*/

  public Authorization getAuthThorization() {
    authorization.setTransactionId("000000000000505");
    authorization.setCardNumber("370000000000505");
    authorization.setSeNumber("9429531213");
    authorization.setSeCountryCode("US");
    authorization.setSeIndustryCategoryCode("5555");
    authorization.setAuthTransactionDate("101112");
    authorization.setAuthTransactionTime("100000");
    authorization.setAuthAmountUSD("200.44");
    authorization.setAuthAmountLocal("10.99");
    authorization.setAuthAmountCurrencyCode("USD");
    authorization.setForeignSpendIndicator("1");
    authorization.setAuth2dac("14");
    authorization.setAuth6dac("123456");
    authorization.setCasMessageSwipeIndicator("1");
    authorization.setTransactionApproveDenyCode("D");
    authorization.setMcc("5555");
    authorization.setFraudLossProbability(0.657);
    authorization.setSeType("I");
    authorization.setCasLogIdentifier("12345678");
    authorization.setSource("CAS");
    authorization.setEcbCreationTime("2019-02-15-16:00:52.503");
    authorization.setJulian("827");
    authorization.setOverwriteIndicator(false);

    return authorization;
  }
}
