package com.aexp.gms.risk.authload.test.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.aexp.gms.imc.risk.rules.vo.keys.CasAuthTransIdCardCacheKey;
import com.aexp.gms.imc.risk.rules.vo.keys.ICacheKey;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthTransIdCardCacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthTransIdCardCacheBean2;
import com.aexp.gms.imc.risk.rules.vo.values.ICacheBean;
import com.aexp.gms.risk.authload.dao.AuthLoadDAOImpl;
import com.aexp.gms.risk.authload.exception.AuthLoadSystemException;
import com.aexp.gms.risk.authload.exception.AuthLoadValidationException;
import com.aexp.gms.risk.authload.model.Authorization;
import com.aexp.gms.risk.authload.model.CacheBean;
import com.aexp.gms.risk.authload.model.CasAuthTransIdCardResponse;
import com.aexp.gms.risk.authload.services.AuthLoadServiceImpl;
import com.aexp.gms.risk.authload.util.AuthLoadConstants;
import com.aexp.gms.risk.authload.util.KafkaProducerConfig;
import com.aexp.gms.risk.data.CassandraAuthDAOImpl;
import java.text.ParseException;
import javax.cache.expiry.ExpiryPolicy;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteDataStreamer;
import org.apache.ignite.IgniteException;
import org.apache.ignite.configuration.CacheConfiguration;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class TestAuthLoadDao {

  private AuthLoadDAOImpl authLoadDAOImpl = null;
  @Mock CassandraAuthDAOImpl cassandraAuthDAOImpl;
  AuthLoadServiceImpl authLoadServiceImpl;
  private KafkaProducerConfig kafkaProducerConfig;
  private static Ignite serverIgnite = null;
  Authorization authorization = new Authorization();
  CacheBean cacheBean = new CacheBean();
  CasAuthTransIdCardCacheBean2 transCardBean = null;

  @Before
  public void setupMock() throws AuthLoadSystemException, ParseException {
    System.setProperty("log4j.configurationFile", "gmsrisk-auth-log4j.xml");
    System.setProperty("env", "e0");
    System.setProperty("spring.profiles.active", "e0");
    System.setProperty("data-center", "ipc1");
    System.setProperty("IGNITE_REST_START_ON_CLIENT", "true");
    System.setProperty("encryptionFlag", "true");
    MockitoAnnotations.initMocks(this);

    if (serverIgnite == null) {
      System.out.println("Starting Ignite server");
      serverIgnite = new IgniteServerNode("ignite-config-server.xml").getIgnite();
    }

    authLoadDAOImpl = new AuthLoadDAOImpl();
    authLoadServiceImpl =
        new AuthLoadServiceImpl(authLoadDAOImpl, cassandraAuthDAOImpl, kafkaProducerConfig);
    authorization = getAuthThorization();
    transCardBean = cacheBean.getTidBean(authorization);
  }

  @Test
  public void testStartIgnite() {
    assertTrue(authLoadDAOImpl.startIgnite());
  }

  /*@Test
  public void testStopIgnite() {
    assertTrue(authLoadDAOImpl.stopIgnite());
  }*/

  @Test
  public void testActivateIgnite() throws AuthLoadSystemException {
    assertTrue(authLoadDAOImpl.activateIgnite());
  }

  @Test
  public void testResetSemaphore() throws AuthLoadSystemException {
    assertEquals(authLoadDAOImpl.resetSemaPhore("*"), 1);
  }

  @Test
  public void testGetCache() throws AuthLoadSystemException {
    assertTrue(authLoadDAOImpl.getCache());
  }

  @Test
  public void testGetCacheByName() throws AuthLoadSystemException {
    // getCache method does 3 things as below
    // 1 if method returns true then API is success so need to test with return type as true
    // 2 also it populates casAuthCache instance so it need to checked using assertNotNull
    // 3 Also this API sets value of the cache name, so need to assert equals for the cache name
    assertTrue(authLoadDAOImpl.getCache(AuthLoadConstants.CAS_AUTH_TID_CM_CACHE));
    CacheConfiguration<ICacheKey, ICacheBean> casCacheCfg =
        new CacheConfiguration<>(AuthLoadConstants.CAS_AUTH_TID_CM_CACHE);
    try {
      IgniteCache<ICacheKey, ICacheBean> casAuthCache =
          authLoadDAOImpl.getIgnite().getOrCreateCache(casCacheCfg);
      assertNotNull(casAuthCache);
      assertEquals(AuthLoadConstants.CAS_AUTH_TID_CM_CACHE, casAuthCache.getName());
    } catch (IgniteException igniteException) {
      throw new AuthLoadSystemException(
          "System Exception while reading cache from Ignite : {} ", igniteException);
    }
  }

  @Test
  public void testLoadCache() throws Exception {
    assertTrue(authLoadDAOImpl.loadCache(transCardBean));
    Ignite ignite = authLoadDAOImpl.getIgnite();
    IgniteCache<ICacheKey, ICacheBean> cache = ignite.cache(transCardBean.getCacheName());
    ExpiryPolicy expiryPolicy = transCardBean.getExpiryPolicy();
    if (cache != null) {
      ICacheBean iCacheBean = cache.withExpiryPolicy(expiryPolicy).get(transCardBean.getCacheKey());
      assertEquals(transCardBean.getCacheConfig(), iCacheBean.getCacheConfig());
      assertEquals(transCardBean.getCacheKey(), iCacheBean.getCacheKey());
      assertEquals(transCardBean.getCacheName(), iCacheBean.getCacheName());
      assertEquals(transCardBean.getTableName(), iCacheBean.getTableName());
      assertEquals(transCardBean.getExpiryPolicy(), iCacheBean.getExpiryPolicy());
      assertEquals(transCardBean.getTableName(), iCacheBean.getTableName());
    }
  }

  @Test
  public void testLoadCacheByName() throws Exception {
    assertTrue(
        authLoadDAOImpl.loadCache(
            AuthLoadConstants.CAS_AUTH_TID_CM_CACHE,
            transCardBean,
            transCardBean.getExpiryPolicy()));

    Ignite ignite = authLoadDAOImpl.getIgnite();
    IgniteCache<ICacheKey, ICacheBean> cache =
        ignite.cache(AuthLoadConstants.CAS_AUTH_TID_CM_CACHE);
    ExpiryPolicy expiryPolicy = transCardBean.getExpiryPolicy();
    ICacheBean iCacheBean = cache.withExpiryPolicy(expiryPolicy).get(transCardBean.getCacheKey());
    assertEquals(transCardBean.getCacheConfig(), iCacheBean.getCacheConfig());
    assertEquals(transCardBean.getCacheKey(), iCacheBean.getCacheKey());
    assertEquals(transCardBean.getCacheName(), iCacheBean.getCacheName());
    assertEquals(transCardBean.getTableName(), iCacheBean.getTableName());
    assertEquals(transCardBean.getExpiryPolicy(), iCacheBean.getExpiryPolicy());
    assertEquals(transCardBean.getTableName(), iCacheBean.getTableName());
  }

  @Test
  public void testValidateCacheVersion() {
    // This API sets value in the cache for the given key using cache.put(key)
    // So testing this API with same values using cache.get(key) using assertNotNull
    authLoadDAOImpl.validateCacheVersion();
    CasAuthTransIdCardCacheBean bean = new CasAuthTransIdCardCacheBean();
    bean.setCardNumber("370000000000200");
    bean.setTransactionId("000000000000200");
    bean.setApproveDenyCode("D");
    CasAuthTransIdCardCacheKey key = (CasAuthTransIdCardCacheKey) bean.getCacheKey();

    IgniteCache<ICacheKey, ICacheBean> cache =
        authLoadDAOImpl.getIgnite().cache("GMS_CAS_AUTH_TID_CM_CACHE_V3");
    assertNotNull(cache.get(key));
  }

  // @Test
  public void testGetCacheCount() throws Exception {
    authLoadServiceImpl.authLoadRequest(authorization);

    // Now check count after inserting authorization
    assertTrue(authLoadDAOImpl.getCacheCount(AuthLoadConstants.CAS_AUTH_TID_CM_CACHE_V3) >= 0);
    assertTrue(authLoadDAOImpl.getCacheCount(AuthLoadConstants.CAS_AUTH_CM_DAC2_CACHE) >= 0);
    assertTrue(authLoadDAOImpl.getCacheCount(AuthLoadConstants.CAS_AUTH_CM_DAC6_CACHE) >= 0);
  }

  @Test
  public void testResetIgniteConnection() throws AuthLoadSystemException {
    // This API sets the value for the ignite instance from null to value returned from
    // Ignition.getOrStart();
    // After successful execution of this API ignite instance should not be null, so same can be
    // checked to validate this test
    // Also this API return true after successful execution so same can be tested
    // assertTrue(authLoadDAOImpl.resetIgniteConnection());
    assertNotNull(authLoadDAOImpl.getIgnite());
  }

  @Test
  public void testGetCASAuthDataByTid()
      throws AuthLoadSystemException, AuthLoadValidationException {
    authLoadServiceImpl.authLoadRequest(authorization);
    CasAuthTransIdCardResponse casAuthDataByTid =
        authLoadDAOImpl.getCASAuthDataByTid(authorization.getTransactionId());
    // getCASAuthDataByTid api sets List<CasAuthTransIdCardCacheBean> on the
    // CasAuthTransIdCardResponse object
    // So testing this API using size as getCacheSummary returns List<CasAuthTransIdCardCacheBean>
    assertTrue(casAuthDataByTid.getCacheSummary().size() >= 0);
  }

  @Test
  public void testGetIgniteStreamer() throws AuthLoadSystemException {
    IgniteDataStreamer<ICacheKey, ICacheBean> stmr =
        authLoadDAOImpl.getIgniteStreamer(AuthLoadConstants.CAS_AUTH_TID_CM_CACHE);
    assertEquals(stmr.perNodeBufferSize(), 1024);
    assertEquals(stmr.perNodeParallelOperations(), 8);
  }

  public Authorization getAuthThorization() {
    authorization.setTransactionId("000000000000505");
    authorization.setCardNumber("370000000000505");
    authorization.setSeNumber("9429531213");
    authorization.setSeCountryCode("US");
    authorization.setSeIndustryCategoryCode("5555");
    authorization.setAuthTransactionDate("101112");
    authorization.setAuthTransactionTime("100000");
    authorization.setAuthAmountUSD("200.44");
    authorization.setAuthAmountLocal("10.99");
    authorization.setAuthAmountCurrencyCode("USD");
    authorization.setForeignSpendIndicator("1");
    authorization.setAuth2dac("14");
    authorization.setAuth6dac("123456");
    authorization.setCasMessageSwipeIndicator("1");
    authorization.setTransactionApproveDenyCode("D");
    authorization.setMcc("5555");
    authorization.setFraudLossProbability(0.657);
    authorization.setSeType("I");
    authorization.setCasLogIdentifier("12345678");
    authorization.setSource("CAS");
    authorization.setEcbCreationTime("2019-02-15-16:00:52.503");
    authorization.setJulian("827");
    authorization.setOverwriteIndicator(true);

    return authorization;
  }
}
