package com.aexp.gms.risk.authload.test;

import com.aexp.gms.risk.authload.exception.AuthLoadSystemException;
import org.junit.Before;
import org.mockito.MockitoAnnotations;

// import com.aexp.gmnt.imc.ignite.IgniteProvider;

// @ContextConfiguration(locations = {"classpath:*test-authload-spring-config.xml"})
// @RunWith(SpringJUnit4ClassRunner.class)
public class AbstractTest {
  // private static Ignite serverIgnite = null;
  @Before
  public void testSetupMock() throws AuthLoadSystemException {
    // System.setProperty("log4j.configurationFile", "gmsrisk-auth-log4j.xml");
    System.setProperty("env", "e0");
    System.setProperty("spring.profiles.active", "e0");
    // System.setProperty("IGNITE_REST_START_ON_CLIENT", "true");
    System.setProperty("data-center", "local");
    MockitoAnnotations.initMocks(this);
    //	authMatchDAO = new AuthLoadDAOImpl();
    //		authMatchDAO.setIgniteProvider(new IgniteProvider());
    //	authMatchDAO.startIgnite();

    // applicationContext = new ClassPathXmlApplicationContext("test-authload-spring-config.xml");
    //		authMatchDAO = (AuthMatchDAOImpl) applicationContext.getBean("authMatchDAO");
    /*if (serverIgnite == null) {
      System.out.println("Starting Ignite server");
      serverIgnite = new IgniteServerNode("ignite-config-server.xml").getIgnite();
    }*/
  }

  //
}
