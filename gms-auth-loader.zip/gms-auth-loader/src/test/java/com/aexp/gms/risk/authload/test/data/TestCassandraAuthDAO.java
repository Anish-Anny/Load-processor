package com.aexp.gms.risk.authload.test.data;

import com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode2CacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode6CacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthTransIdCardCacheBean2;
import com.aexp.gms.risk.authload.exception.AuthLoadSystemException;
import com.aexp.gms.risk.authload.model.Authorization;
import com.aexp.gms.risk.authload.model.CacheBean;
import com.aexp.gms.risk.data.CassandraAuthDAOImpl;
import com.datastax.driver.core.ResultSet;
import java.util.concurrent.TimeUnit;
import javax.cache.expiry.CreatedExpiryPolicy;
import javax.cache.expiry.Duration;
import org.junit.Before;
import org.junit.Test;

public class TestCassandraAuthDAO {

  CasAuthTransIdCardCacheBean2 transCardBean = null;
  CasAuthCardAccessCode6CacheBean cardDac6Bean = null;
  CasAuthCardAccessCode2CacheBean cardDac2Bean = null;
  static Authorization authorization = null;
  // private static Ignite serverIgnite = null;
  // static CassandraTestData testData = new CassandraTestData();

  @Before
  public void setupMock() throws AuthLoadSystemException {
    System.setProperty("log4j.configurationFile", "gmsrisk-authmatch-processor-log4j.xml");
    System.setProperty("env", "test");
    System.setProperty("spring.profiles.active", "e0");
    System.setProperty("data-center", "ipc1");
    System.setProperty("env", "e0");
    System.setProperty("IGNITE_REST_START_ON_CLIENT", "true");
    authorization = new Authorization();

    /* if (serverIgnite == null) {
      System.out.println("Starting Ignite server");
      serverIgnite = new IgniteServerNode("ignite-config-server.xml").getIgnite();
    }*/
  }

  @Test
  public void testInsertAuthorizations() throws Exception {
    // System.out.println("test");

    authorization = getAuthThorization();
    CacheBean cacheBean = new CacheBean();

    transCardBean = cacheBean.getTidBean(authorization);
    cardDac6Bean = cacheBean.getCardDac6Bean(authorization);
    cardDac2Bean = cacheBean.getCardDac2Bean(authorization);

    CassandraAuthDAOImpl cassandraAuthDAOImpl = new CassandraAuthDAOImpl();
    cassandraAuthDAOImpl.insertAuthorization(
        authorization, transCardBean, cardDac6Bean, cardDac2Bean);
    ResultSet resultSet = null;
    // assertTrue(cassandraAuthDAOImpl.getCountFromAuthTable(transCardBean) > 0);
    /*ResultSet resultSet = cassandraAuthDAOImpl.getDataFromAuthTable(transCardBean);
    for (Row row : resultSet) {
      assertEquals(row.getString("trans_id"), authorization.getTransactionId());
      assertEquals(row.getString("cm15"), authorization.getCardNumber());
      assertEquals(row.getString("se10"), authorization.getSeNumber());
      assertEquals(row.getString("se_ctry_cd"), authorization.getSeCountryCode());
      assertEquals(row.getString("se_indus_ctgy_cd"), authorization.getSeIndustryCategoryCode());
      assertEquals(
          row.getDecimal("auth_am_in_usd"), new BigDecimal(authorization.getAuthAmountUSD()));
      assertEquals(
          row.getDecimal("auth_am_in_local_curr"),
          new BigDecimal(authorization.getAuthAmountLocal()));
      assertEquals(row.getString("auth_curr"), authorization.getAuthAmountCurrencyCode());
      assertEquals(row.getString("frgn_sepnd_in"), authorization.getForeignSpendIndicator());
      assertEquals(row.getString("auth2dac_appr_cd"), authorization.getAuth2dac());
      assertEquals(row.getString("auth6dac_appr_cd"), authorization.getAuth6dac());
      assertEquals(row.getString("mag_swipe_in"), authorization.getCasMessageSwipeIndicator());
      assertEquals(row.getString("aprv_deny_cd"), authorization.getTransactionApproveDenyCode());
      assertEquals(row.getString("mcc"), authorization.getMcc());
      assertEquals(
          new Float(row.getFloat("frd_loss_prbl_score")),
          new Float(authorization.getFraudLossProbability()));
      assertEquals(row.getString("se_type_cd"), authorization.getSeType());
      assertEquals(row.getString("lwrcw_7dlog_tx"), authorization.getCasLogIdentifier());
      assertEquals(row.getString("sourceid"), authorization.getSource());
    }*/

    // assertTrue(cassandraAuthDAOImpl.getCountFromAuthByTransIdTable(authorization) > 0);
    resultSet = cassandraAuthDAOImpl.getDataFromAuthByTransIdTable(authorization);
    /*for (Row row : resultSet) {
      assertEquals(row.getString("trans_id"), authorization.getTransactionId());
      assertEquals(row.getString("cm_15"), authorization.getCardNumber());
      assertEquals(row.getString("auth_se_no"), authorization.getSeNumber());
      assertEquals(row.getDecimal("auth_usd_am"), new BigDecimal(authorization.getAuthAmountUSD()));
      assertEquals(
          row.getDecimal("auth_loc_am"), new BigDecimal(authorization.getAuthAmountLocal()));
      assertEquals(row.getString("auth_loc_am_curr_cd"), authorization.getAuthAmountCurrencyCode());
      assertEquals(row.getString("aprv_deny_cd"), authorization.getTransactionApproveDenyCode());
    }*/

    /* assertTrue(
    cassandraAuthDAOImpl.getCountFromAuthBy6dacAndSeTable(authorization, cardDac6Bean) > 0);*/
    resultSet = cassandraAuthDAOImpl.getDataFromAuthBy6dacAndSeTable(authorization, cardDac6Bean);
    /*for (Row row : resultSet) {
      assertEquals(row.getString("cm15"), authorization.getCardNumber());
      assertEquals(row.getString("auth_se_no"), authorization.getSeNumber());
      assertEquals(row.getDecimal("auth_usd_am"), new BigDecimal(authorization.getAuthAmountUSD()));
      assertEquals(
          row.getDecimal("auth_loc_am"), new BigDecimal(authorization.getAuthAmountLocal()));
      assertEquals(row.getString("six_dgt_aprv_cde"), authorization.getAuth6dac());
      assertEquals(row.getString("aprv_deny_cd"), authorization.getTransactionApproveDenyCode());
    }*/

    /*assertTrue(
    cassandraAuthDAOImpl.getCountFromAuthBy2dacAndSeTable(authorization, cardDac2Bean) > 0);*/
    resultSet = cassandraAuthDAOImpl.getDataFromAuthBy2dacAndSeTable(authorization, cardDac2Bean);
    /* for (Row row : resultSet) {
      assertEquals(row.getString("cm15"), authorization.getCardNumber());
      assertEquals(row.getString("auth_se_no"), authorization.getSeNumber());
      assertEquals(row.getDecimal("auth_usd_am"), new BigDecimal(authorization.getAuthAmountUSD()));
      assertEquals(
          row.getDecimal("auth_loc_am"), new BigDecimal(authorization.getAuthAmountLocal()));
      assertEquals(row.getString("two_dgt_aprv_cde"), authorization.getAuth2dac());
      assertEquals(row.getString("aprv_deny_cd"), authorization.getTransactionApproveDenyCode());
    }*/

    // assertTrue(cassandraAuthDAOImpl.getCountFromAuthByCardAndSeTable(authorization) > 0);
  }

  public Authorization getAuthThorization() {
    authorization.setTransactionId("000000000000308");
    authorization.setCardNumber("370000000000308");
    authorization.setSeNumber("9429531213");
    authorization.setSeCountryCode("US");
    authorization.setSeIndustryCategoryCode("5555");
    authorization.setAuthTransactionDate("101112");
    authorization.setAuthTransactionTime("100000");
    authorization.setAuthAmountUSD("200.44");
    authorization.setAuthAmountLocal("10.99");
    authorization.setAuthAmountCurrencyCode("USD");
    authorization.setForeignSpendIndicator("1");
    authorization.setAuth2dac("14");
    authorization.setAuth6dac("123456");
    authorization.setCasMessageSwipeIndicator("1");
    authorization.setTransactionApproveDenyCode("D");
    authorization.setMcc("5555");
    authorization.setFraudLossProbability(0.657);
    authorization.setSeType("I");
    authorization.setCasLogIdentifier("12345678");
    authorization.setSource("CAS");
    authorization.setExpiryPolicy(new CreatedExpiryPolicy(new Duration(TimeUnit.MINUTES, 25)));

    return authorization;
  }
}
