package com.aexp.gms.risk.authload.test.model;

import static org.junit.Assert.assertNotNull;
import static pl.pojo.tester.api.FieldPredicate.includeAllFields;
import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import com.aexp.gms.risk.authload.model.AuthCacheKeyBean;
import com.aexp.gms.risk.authload.model.AuthLoadResponse;
import com.aexp.gms.risk.authload.model.Authorization;
import com.aexp.gms.risk.authload.model.CacheSummary;
import com.aexp.gms.risk.authload.model.CacheSummaryResponse;
import com.aexp.gms.risk.authload.model.ResponseMetaData;
import com.jparams.verifier.tostring.NameStyle;
import com.jparams.verifier.tostring.ToStringVerifier;
import nl.jqno.equalsverifier.EqualsVerifier;
import nl.jqno.equalsverifier.Warning;
import org.junit.Test;
import pl.pojo.tester.api.assertion.Method;

public class ResponseTest {
  @Test
  public void testEqualsAndHashCode() {
    EqualsVerifier.forClass(Authorization.class)
        .suppress(Warning.STRICT_INHERITANCE, Warning.NONFINAL_FIELDS)
        .verify();

    EqualsVerifier.forClass(AuthCacheKeyBean.class)
        .suppress(Warning.STRICT_INHERITANCE, Warning.NONFINAL_FIELDS)
        .verify();
    EqualsVerifier.forClass(AuthLoadResponse.class)
        .suppress(Warning.STRICT_INHERITANCE, Warning.NONFINAL_FIELDS);
  }

  @Test
  public void cacheSummaryResponseTest() {
    final Class<?> cacheSynchup = CacheSummaryResponse.class;

    assertPojoMethodsFor(cacheSynchup, includeAllFields(cacheSynchup))
        .testing(Method.CONSTRUCTOR, Method.GETTER, Method.SETTER)
        .quickly()
        .areWellImplemented();
  }

  @Test
  public void responseMetaDataTest() {

    final Class<?> cacheSynchup = ResponseMetaData.class;
    assertPojoMethodsFor(cacheSynchup, includeAllFields(cacheSynchup))
        .testing(Method.CONSTRUCTOR, Method.GETTER, Method.SETTER)
        .testing(Method.EQUALS, Method.HASH_CODE)
        .quickly()
        .areWellImplemented();

    ResponseMetaData responseMetaData = new ResponseMetaData();
    assertNotNull(responseMetaData.toString());
  }

  @Test
  public void authorizationTest() {
    final Class<?> cacheSynchup = Authorization.class;
    assertPojoMethodsFor(cacheSynchup, includeAllFields(cacheSynchup))
        .testing(
            Method.CONSTRUCTOR,
            Method.GETTER,
            Method.SETTER,
            Method.TO_STRING,
            Method.EQUALS,
            Method.HASH_CODE)
        .quickly()
        .areWellImplemented();
    Authorization.builder().build();
    /*  assertNotNull(
        		Authorization.builder()
                    .auth2dac("DA")
                    .auth6dac("DAC98")
                    .authAmountCurrencyCode("USD")
                    .authAmountLocal("10.0")
                    .authAmountLocal("10.0")
                    .cardNumber("67000054")
                    .dpan("")
                    .ecbCreationTime("2020-01-01 01:01:59")
                    .eciIndicator("")
                    .foreignSpendIndicator("")
                    .fraudLossProbability((double) 1f)
                    .mcc("123")
                    .originalMCC("123")
                    .posDataCode("")
                    .eciIndicator("1")
                    .eciIndicator("T01")
                    .cardNumber("qeqwefasdf")
                    .seNumber("67000054")
                    .seCountryCode("840")
                    .seIndustryCategoryCode("123")
                    .seType("")
                    .transactionId("")
                    .voiceAuthIndicator("")
                    .build());
    */

    assertNotNull(Authorization.builder());
    assertNotNull(Authorization.builder().toString());
    assertNotNull(Authorization.builder().build());

    Authorization authorization = new Authorization();
    assertNotNull(authorization);

    ToStringVerifier.forClass(Authorization.class).withClassName(NameStyle.SIMPLE_NAME);
  }

  @Test
  public void authCacheKeyBeanTest() {
    final Class<?> cacheSynchup = AuthCacheKeyBean.class;

    assertPojoMethodsFor(cacheSynchup, includeAllFields(cacheSynchup))
        .testing(Method.CONSTRUCTOR, Method.GETTER, Method.SETTER, Method.TO_STRING)
        .testing(Method.EQUALS, Method.HASH_CODE)
        .quickly()
        .areWellImplemented();
    AuthCacheKeyBean.builder().build();

    assertNotNull(AuthCacheKeyBean.builder());
    assertNotNull(AuthCacheKeyBean.builder().toString());
    assertNotNull(AuthCacheKeyBean.builder().build());

    AuthCacheKeyBean authCacheKeyBean = new AuthCacheKeyBean();
    assertNotNull(authCacheKeyBean);

    ToStringVerifier.forClass(AuthCacheKeyBean.class).withClassName(NameStyle.SIMPLE_NAME).verify();
  }

  @Test
  public void authLoadResponseTest() {
    final Class<?> cacheSynchup = AuthLoadResponse.class;

    assertPojoMethodsFor(cacheSynchup, includeAllFields(cacheSynchup))
        .testing(Method.CONSTRUCTOR)
        .quickly()
        .areWellImplemented();
    AuthLoadResponse authLoadResponse = new AuthLoadResponse();
    ResponseMetaData responseMetaData = new ResponseMetaData();
    //    responseMetaData.set();

  }

  @Test
  public void CacheSummaryTest() {
    final Class<?> cacheSynchup = CacheSummary.class;

    assertPojoMethodsFor(cacheSynchup, includeAllFields(cacheSynchup))
        .testing(Method.GETTER, Method.SETTER)
        .quickly()
        .areWellImplemented();
  }
}
