package com.aexp.gms.risk.authload.test.exception;

import com.aexp.gms.risk.authload.exception.AuthLoadValidationException;
import org.junit.Assert;
import org.junit.Test;

public class TestAuthLoadValidationException {
  @Test
  public void testAuthMatchException() {
    AuthLoadValidationException exception = new AuthLoadValidationException();
    Assert.assertNotNull(exception);
  }

  @Test
  public void testAuthMatchExceptionWithMessage() {
    AuthLoadValidationException exception = new AuthLoadValidationException("Error caught");
    Assert.assertNotNull(exception);
  }

  @Test
  public void testAuthMatchExceptionMessageAndTrhowable() {
    AuthLoadValidationException exception =
        new AuthLoadValidationException("Error caught", new Throwable());
    Assert.assertNotNull(exception);
  }

  @Test
  public void testAuthMatchExceptionThrowable() {
    AuthLoadValidationException exception = new AuthLoadValidationException(new Throwable());
    Assert.assertNotNull(exception);
  }
}
