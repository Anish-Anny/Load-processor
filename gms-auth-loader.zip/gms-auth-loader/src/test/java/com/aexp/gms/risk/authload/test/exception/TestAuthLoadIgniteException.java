package com.aexp.gms.risk.authload.test.exception;

import com.aexp.gms.risk.authload.exception.AuthLoadIgniteException;
import org.junit.Assert;
import org.junit.Test;

public class TestAuthLoadIgniteException {
  @Test
  public void testAuthMatchException() {
    AuthLoadIgniteException exception = new AuthLoadIgniteException();
    Assert.assertNotNull(exception);
  }

  @Test
  public void testAuthMatchExceptionWithMessage() {
    AuthLoadIgniteException exception = new AuthLoadIgniteException("Error caught");
    Assert.assertNotNull(exception);
  }

  @Test
  public void testAuthMatchExceptionMessageAndTrhowable() {
    AuthLoadIgniteException exception =
        new AuthLoadIgniteException("Error caught", new Throwable());
    Assert.assertNotNull(exception);
  }

  @Test
  public void testAuthMatchExceptionThrowable() {
    AuthLoadIgniteException exception = new AuthLoadIgniteException(new Throwable());
    Assert.assertNotNull(exception);
  }
}
