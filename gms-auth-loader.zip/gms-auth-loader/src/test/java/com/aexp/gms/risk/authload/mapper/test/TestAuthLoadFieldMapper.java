package com.aexp.gms.risk.authload.mapper.test;

import static org.junit.Assert.assertEquals;

import com.aexp.gms.risk.authload.exception.AuthLoadValidationException;
import com.aexp.gms.risk.authload.mapper.AuthLoadFieldMapper;
import com.aexp.gms.risk.cas.auth.AW;
import com.aexp.gms.risk.cas.auth.AuthSchema;
import com.aexp.gms.risk.cas.auth.CC;
import com.aexp.gms.risk.cas.auth.CW;
import com.aexp.gms.risk.cas.auth.DX;
import com.aexp.gms.risk.cas.auth.IS;
import com.aexp.gms.risk.cas.auth.RR;
import com.aexp.gms.risk.cas.auth.S3;
import com.aexp.gms.risk.nemo.auth.Context;
import com.aexp.gms.risk.nemo.auth.Df31;
import com.aexp.gms.risk.nemo.auth.Gptn;
import com.aexp.gms.risk.nemo.auth.MergeResult;
import com.aexp.gms.risk.nemo.auth.MtNorm;
import com.aexp.gms.risk.nemo.auth.MtPar;
import com.aexp.gms.risk.nemo.auth.NemoSchema;
import com.aexp.gms.risk.nemo.auth.ParsedMsg;
import com.aexp.gms.risk.nemo.auth.Transaction;
import com.aexp.gms.risk.nemo.auth.Workflow;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestAuthLoadFieldMapper {

  // private static Ignite serverIgnite = null;
  @BeforeClass
  public static void setup() {
    System.setProperty("env", "e0");
    /*System.setProperty("IGNITE_REST_START_ON_CLIENT", "true");

    if (serverIgnite == null) {
        System.out.println("Starting Ignite server");
        serverIgnite = new IgniteServerNode("ignite-config-server.xml").getIgnite();
      }*/
  }

  @Test
  public void testMap() throws AuthLoadValidationException {
    System.setProperty("AIM_ID", "41140955");

    AuthLoadFieldMapper authLoadFieldMapper = new AuthLoadFieldMapper();

    AuthSchema casAuthBean = new AuthSchema();
    AW aw = new AW();
    aw.setFRGNIND("1");
    casAuthBean.setAW(aw);

    CC cc = new CC();
    cc.setCONVAMT("563.92");
    // cc.setMGSTRPCD(mGSTRPCD);
    cc.setOMCC("4494");
    casAuthBean.setCC(cc);

    CW cw = new CW();
    cw.setAPPDENY("6");
    cw.setDGOD("20190211");
    cw.setLSEQNO("310");
    //  cw.setSRCTYPE(sRCTYPE);
    cw.setTID8583("005681103215275");
    cw.setTMOFDYIN("094834");
    cw.setTRNSDTTM("2020-09-08 16:00:52:503");
    casAuthBean.setCW(cw);

    DX dx = new DX();
    dx.setJULIAN("837");
    casAuthBean.setDX(dx);

    IS is = new IS();
    is.setAMOUNT("563.92");
    is.setLACCT19("376661207886008");
    is.setCRRNTYP("USD");
    is.setSENUM15("1030009096");
    casAuthBean.setIS(is);

    RR rr = new RR();
    rr.setAPPRVLCD("DA");
    rr.setAPRVCD("DAC98");
    casAuthBean.setRR(rr);

    S3 s3 = new S3();
    s3.setAMEXMCC("5555");
    s3.setSBFSCD("RET");
    s3.setTCNTRYX("US");
    casAuthBean.setS3(s3);

    authLoadFieldMapper.map(casAuthBean);

    assertEquals(casAuthBean.getAW().getFRGNIND(), "1");

    assertEquals(casAuthBean.getCC().getCONVAMT(), "563.92");
    assertEquals(casAuthBean.getCC().getOMCC(), "4494");

    assertEquals(casAuthBean.getCW().getAPPDENY(), "6");
    assertEquals(casAuthBean.getCW().getDGOD(), "20190211");
    assertEquals(casAuthBean.getCW().getLSEQNO(), "310");

    assertEquals(casAuthBean.getCW().getTID8583(), "005681103215275");
    assertEquals(casAuthBean.getCW().getTMOFDYIN(), "094834");
    assertEquals(casAuthBean.getCW().getTRNSDTTM(), "2020-09-08 16:00:52:503");

    assertEquals(casAuthBean.getDX().getJULIAN(), "837");

    assertEquals(casAuthBean.getIS().getAMOUNT(), "563.92");
    assertEquals(casAuthBean.getIS().getLACCT19(), "376661207886008");
    assertEquals(casAuthBean.getIS().getCRRNTYP(), "USD");
    assertEquals(casAuthBean.getIS().getSENUM15(), "1030009096");

    assertEquals(casAuthBean.getRR().getAPPRVLCD(), "DA");
    assertEquals(casAuthBean.getRR().getAPRVCD(), "DAC98");

    assertEquals(casAuthBean.getS3().getAMEXMCC(), "5555");
    assertEquals(casAuthBean.getS3().getSBFSCD(), "RET");
    assertEquals(casAuthBean.getS3().getTCNTRYX(), "US");
  }

  @Test
  public void testMap11() {

    AuthLoadFieldMapper authLoadFieldMapper = new AuthLoadFieldMapper();
    NemoSchema nemoSchema = new NemoSchema();
    authLoadFieldMapper.getTransaction(nemoSchema);
    authLoadFieldMapper.getContext(nemoSchema);
    authLoadFieldMapper.getMergeResult(nemoSchema);
    Workflow workflow = new Workflow();
    Context context = new Context();
    Gptn gptn = new Gptn();
    Df31 df31 = new Df31();
    MergeResult mergeResult = new MergeResult();
    MtNorm mtNorm = new MtNorm();
    MtPar mt_par = new MtPar();
    ParsedMsg parsed_msg = new ParsedMsg();
    Transaction transaction = new Transaction();

    nemoSchema.setWorkflow(workflow);
    workflow.setContext(context);
    context.setDf31(df31);
    context.setGptn(gptn);
    gptn.setMtNorm(mtNorm);
    gptn.setMtPar(mt_par);
    df31.setMergeResult(mergeResult);
    mergeResult.setApprovalCode("A");
    mergeResult.setTransactionApproveDenyCode("A");
    mergeResult.setTransactionIdentifier("");
    mtNorm.setTransaction(transaction);
    mt_par.setParsedMsg(parsed_msg);
    parsed_msg.setCardAcceptorCountryCode("");

    transaction.setAcquirerCountryCode("840");
    transaction.setCardAcceptorIdentificationCode("4105493688");
    transaction.setLocalDateTime("2019-0619T12:23:45.000");
    transaction.setMerchantCategoryCode("7380");
    transaction.setPrimaryAccountNumber("000000002163");
    transaction.setTransactionAmount("000000002163");
    transaction.setTransactionCurrencyCode("840");

    authLoadFieldMapper.map(nemoSchema);
    assertEquals(nemoSchema.getWorkflow().getContext(), context);
    assertEquals(nemoSchema.getWorkflow().getContext().getDf31(), df31);
    assertEquals(nemoSchema.getWorkflow().getContext().getGptn(), gptn);
    assertEquals(nemoSchema.getWorkflow().getContext().getDf31().getMergeResult(), mergeResult);
    assertEquals(
        nemoSchema.getWorkflow().getContext().getDf31().getMergeResult().getApprovalCode(), "A");
    assertEquals(
        nemoSchema
            .getWorkflow()
            .getContext()
            .getDf31()
            .getMergeResult()
            .getTransactionApproveDenyCode(),
        "A");
    assertEquals(
        nemoSchema.getWorkflow().getContext().getDf31().getMergeResult().getTransactionIdentifier(),
        "");
    assertEquals(nemoSchema.getWorkflow().getContext().getGptn().getMtPar(), mt_par);
    assertEquals(nemoSchema.getWorkflow().getContext().getGptn().getMtNorm(), mtNorm);
    assertEquals(
        nemoSchema.getWorkflow().getContext().getGptn().getMtPar().getParsedMsg(), parsed_msg);
    assertEquals(
        nemoSchema
            .getWorkflow()
            .getContext()
            .getGptn()
            .getMtPar()
            .getParsedMsg()
            .getCardAcceptorCountryCode(),
        "");

    assertEquals(
        nemoSchema.getWorkflow().getContext().getGptn().getMtNorm().getTransaction(), transaction);

    assertEquals(
        nemoSchema
            .getWorkflow()
            .getContext()
            .getGptn()
            .getMtNorm()
            .getTransaction()
            .getAcquirerCountryCode(),
        "840");
    assertEquals(
        nemoSchema
            .getWorkflow()
            .getContext()
            .getGptn()
            .getMtNorm()
            .getTransaction()
            .getCardAcceptorIdentificationCode(),
        "4105493688");
    assertEquals(
        nemoSchema
            .getWorkflow()
            .getContext()
            .getGptn()
            .getMtNorm()
            .getTransaction()
            .getLocalDateTime(),
        "2019-0619T12:23:45.000");
    assertEquals(
        nemoSchema
            .getWorkflow()
            .getContext()
            .getGptn()
            .getMtNorm()
            .getTransaction()
            .getMerchantCategoryCode(),
        "7380");
    assertEquals(
        nemoSchema
            .getWorkflow()
            .getContext()
            .getGptn()
            .getMtNorm()
            .getTransaction()
            .getPrimaryAccountNumber(),
        "000000002163");
    assertEquals(
        nemoSchema
            .getWorkflow()
            .getContext()
            .getGptn()
            .getMtNorm()
            .getTransaction()
            .getTransactionAmount(),
        "000000002163");
    assertEquals(
        nemoSchema
            .getWorkflow()
            .getContext()
            .getGptn()
            .getMtNorm()
            .getTransaction()
            .getTransactionCurrencyCode(),
        "840");
  }
}
