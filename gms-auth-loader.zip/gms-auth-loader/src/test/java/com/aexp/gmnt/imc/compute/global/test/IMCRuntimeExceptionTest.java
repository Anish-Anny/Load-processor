package com.aexp.gmnt.imc.compute.global.test;

import com.aexp.gmnt.imc.compute.global.IMCRuntimeException;
import org.junit.Assert;
import org.junit.Test;

public class IMCRuntimeExceptionTest {
  @Test
  public void testIMCRuntimeExceptionException() {
    IMCRuntimeException exception = new IMCRuntimeException();
    Assert.assertNotNull(exception);
  }

  @Test
  public void testIMCRuntimeExceptionExceptionWithMessage() {
    IMCRuntimeException exception = new IMCRuntimeException("Error caught");
    Assert.assertNotNull(exception);
  }

  @Test
  public void testIMCRuntimeExceptionExceptionMessageAndTrhowable() {
    IMCRuntimeException exception = new IMCRuntimeException("Error caught", new Throwable());
    Assert.assertNotNull(exception);
  }

  @Test
  public void testIMCRuntimeExceptionExceptionThrowable() {
    IMCRuntimeException exception = new IMCRuntimeException(new Throwable());
    Assert.assertNotNull(exception);
  }

  @Test
  public void testIMCRuntimeExceptionThrowableFourAgrs() {
    IMCRuntimeException exception =
        new IMCRuntimeException("Error caught", new Throwable(), true, true);
    Assert.assertNotNull(exception);
  }
}
