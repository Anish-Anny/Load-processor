package com.aexp.gmnt.imc.compute.global.test;

import com.aexp.gmnt.imc.compute.global.IMCProcessException;
import org.junit.Assert;
import org.junit.Test;

public class IMCProcessExceptionTest {
  @Test
  public void testIMCRuntimeException() {
    IMCProcessException exception = new IMCProcessException();
    Assert.assertNotNull(exception);
  }

  @Test
  public void testIMCRuntimeExceptionnWithMessage() {
    IMCProcessException exception = new IMCProcessException("Error caught");
    Assert.assertNotNull(exception);
  }

  @Test
  public void testIMCRuntimeExceptionExceptionMessageAndTrhowable() {
    IMCProcessException exception = new IMCProcessException("Error caught", new Throwable());
    Assert.assertNotNull(exception);
  }

  @Test
  public void testIMCRuntimeExceptionExceptionThrowable() {
    IMCProcessException exception = new IMCProcessException(new Throwable());
    Assert.assertNotNull(exception);
  }

  @Test
  public void testIMCRuntimeExceptionThrowableFourAgrs() {
    IMCProcessException exception =
        new IMCProcessException("Error caught", new Throwable(), true, true);
    Assert.assertNotNull(exception);
  }
}
