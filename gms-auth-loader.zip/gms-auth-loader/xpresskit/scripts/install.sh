#!/bin/bash
# Script to move files from packaged artifact to different directories on the server

# Call the set environment script to set variable
source setenv.sh
# Back up all files before making any changes.

# Termination for AuthLoad program will fail if application not terminated before install
for pid in ` ps aux | grep server.port=8282 | grep app.jar | awk '{print $2}'` ; do kill $pid ; done
sleep 10 
echo "Killing AuthLoad with PID: $pid"
for pid in ` ps aux | grep server.port=8282 | grep app.jar | awk '{print $2}'` ; do proc=$pid ; done
if [ -v proc ];then
        echo "Application is still running, waiting 20 seconds."
        sleep 20
fi
for pid in ` ps aux | grep server.port=8282 | grep app.jar | awk '{print $2}'` ; do proc2=$pid ; done
if [ -v proc2 ];then
        echo "Application is still not terminated waiting another 20 seconds."
        sleep 20
fi
for pid in ` ps aux | grep server.port=8282| grep app.jar | awk '{print $2}'` ; do proc3=$pid ; done
if [ -v proc3 ];then
        echo "Application failed to terminate, deployment failure"
        exit 1
fi

# Back up all files before making any changes.
START_DIR=$(pwd)
# create a temp directory for backup
TMP_DIR="$(date +"backup_%d_%m_%Y")"
/bin/su -c "mkdir -p $BACKUP_FOLDER""$TMP_DIR" gridgain

echo ""
echo "$(date +"%H:%M:%S") Back up of files starting" 
cd "$BACKUP_FOLDER$TMP_DIR"
shopt -s nullglob
numfiles=(*)
numfiles=${#numfiles[@]}
numfilesADD1=$((numfiles + 1))
# Loop through the file list and backup the file
for file in ${FILE_TO_COPY//,/ }
do
    if [ -e "$DEST_FOLDER$file" ]
    then
      echo "$(date +"%H:%M:%S") Taking back up of $file"
      /bin/su -c "mv $DEST_FOLDER$file $BACKUP_FOLDER$TMP_DIR/$file""_$numfilesADD1" gridgain
    else
      echo "$(date +"%H:%M:%S") $file not present in $DEST_FOLDER"
      exit 1
    fi
done
echo "$(date +"%H:%M:%S") Back up of files completed" 

echo ""
echo "$(date +"%H:%M:%S") Copying latest  files starting"
# Loop through the file list and move it to destination folder
cd $START_DIR
for file in ${FILE_TO_COPY//,/ }
do
	if [ -e "$SRC_FOLDER$file" ]
	then
    	echo "$(date +"%H:%M:%S") Moving $file to $DEST_FOLDER"
    	/bin/su -c "mv $SRC_FOLDER$file $DEST_FOLDER" gridgain
	else 
		echo "$(date +"%H:%M:%S") $file not present in $SRC_FOLDER"
		exit 1
	fi
done
echo "$(date +"%H:%M:%S") Copying latest  files completed"
echo "$(date +"%H:%M:%S") Starting Application"
cd "$DEST_FOLDER"
/bin/su -c "nohup java -Xms512m -Xmx512m -jar -Dspring.profiles.active=$ENV -DAIM_ID=41140955 -DAPP_NAME=GMS_AUTH_LOAD -Dlog4j.configurationFile=log4j2.xml -Dserver.port=8282 -Denv=$ENV -Ddata-center=$DData -Djava.net.preferIPv4Stack=true app.jar >/dev/null 2>&1 &" gridgain
echo "$(date +"%H:%M:%S") Process finished *********"
exit 0 



