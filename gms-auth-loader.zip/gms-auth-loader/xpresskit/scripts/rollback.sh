#!/bin/bash
# Script to rollback changes made during install script execution

# Call the set environment script to set variable
source setenv.sh

# getting temp directory for backup, assuming rollback on same day
TMP_DIR="$(date +"backup_%d_%m_%Y")"
cd "$BACKUP_FOLDER$TMP_DIR"
shopt -s nullglob
numfiles=(*)
numfiles=${#numfiles[@]}
for file in ${FILE_TO_COPY//,/ }
do
	echo "$(date +"%H:%M:%S") Restoring $file""_$numfiles from $BACKUP_FOLDER$TMP_DIR"
	/bin/su -c "mv $BACKUP_FOLDER$TMP_DIR/$file""_$numfiles $DEST_FOLDER$file" gridgain
done
echo "$(date +"%H:%M:%S") Rollback of files completed" 

cd "$BACKUP_FOLDER$TMP_DIR"
shopt -s nullglob
numfiles=(*)
numfiles=${#numfiles[@]}
if [ $numfiles = 0 ]; then
	echo "$(date +"%H:%M:%S") Removing the backup directory"
	/bin/su -c "rm -r $BACKUP_FOLDER$TMP_DIR" gridgain
fi 

echo "$(date +"%H:%M:%S") Starting Application"
cd "$DEST_FOLDER"
for pid in ` ps aux | grep server.port=8282 | awk '{print $2}'` ; do kill $pid ; done
sleep 10
/bin/su -c "nohup java -Xms512m -Xmx512m -jar -Dspring.profiles.active=$ENV -Dserver.port=8282 -DAIM_ID=41140955 -DAPP_NAME=GMS_AUTH_LOAD -Dlog4j.configurationFile=log4j2.xml -Denv=$ENV -Ddata-center=$DData -Djava.net.preferIPv4Stack=true app.jar >/dev/null 2>&1 &" gridgain
echo "$(date +"%H:%M:%S") Process finished *********"
exit 0 